package fr.obeo.reverse.vb.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Quentin Glineur (Obeo)
 * This application blaze code with markers aroud statements blocks
 */
public final class BlazeBodyCode {
	/**
	 * List of strings used to locate where to put marks.
	 */
	private static final List <String> BEGIN_DELIMITERS = new ArrayList <String>();
	static {
		BEGIN_DELIMITERS.add("Sub");
		BEGIN_DELIMITERS.add("Function");
		BEGIN_DELIMITERS.add("Set");
		BEGIN_DELIMITERS.add("Get");
		BEGIN_DELIMITERS.add("Let");
	}

	/**
	 * Prevents instantiation.
	 */
	private BlazeBodyCode() {		
	}

	/**
	 * @param args imput file path (absolute), output file path (absolute)
	 */
	public static void main(final String[] args) {
		String arg1 = args[0];
		String arg2 = args[1];
		BufferedReader bufferedReader;
		FileWriter fileWriter;
		File outputFile = null;
		try {
			String currentEndBlockSearch = null;
			outputFile = new File(arg2);
			outputFile.createNewFile();
			bufferedReader = new BufferedReader(new FileReader(arg1));
			fileWriter = new FileWriter(outputFile);
			String line;
			boolean beginDelimiterFound = false;
			boolean beginMarkPositionFound = false;
			boolean endMarkPositionFound = false;
			List<String> tempList;
			while ((line = bufferedReader.readLine()) != null) {
				if (!line.startsWith("'")) { //skip comments
					if (!beginDelimiterFound) { //skip following code in case of resumed line (finishing by an underscore)
						StringTokenizer stringTokenizer = new StringTokenizer(line);
						List<String> tokenList = new ArrayList<String>();
						while (stringTokenizer.hasMoreTokens()) {
							tokenList.add(stringTokenizer.nextToken());
						}
						tempList = new ArrayList<String>();
						tempList.addAll(tokenList);
						if (currentEndBlockSearch == null) {
							//intersection of tokens with delimiters
							tempList.retainAll(BEGIN_DELIMITERS);
							//consider a begin mark if there is no "declare" token
							beginDelimiterFound = (!tokenList.contains("Declare") && !tempList.isEmpty());
							if (beginDelimiterFound) {
								//record the char sequence to serve as a end for code block
								currentEndBlockSearch = tempList.get(0);
								if (currentEndBlockSearch.equals("Let") || currentEndBlockSearch.equals("Get") || currentEndBlockSearch.equals("Set")) {
									currentEndBlockSearch = "Property";
								}
							}
						} else { //in search for end of a block
							int endIndex = tempList.indexOf("End");
							if ((endIndex != -1) && (tempList.indexOf(currentEndBlockSearch) == endIndex + 1)) {
								endMarkPositionFound = true;
							}
						}
					}
					if (beginDelimiterFound && !line.endsWith("_")) {
						//consider this is the place for the mark
						beginMarkPositionFound = true;
						beginDelimiterFound = false;
					}
					if (endMarkPositionFound) {
						//mark code and reset control variables
						fileWriter.write("'body\n");
						endMarkPositionFound = false;
						currentEndBlockSearch = null;
					}
				}
				//copy code
				fileWriter.write(line + "\n");
				if (beginMarkPositionFound) {
					//mark code and reset control variables
					fileWriter.write("'body\n");
					beginMarkPositionFound = false;
				}
			}
			bufferedReader.close();
			fileWriter.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
