package fr.obeo.reverse.vb.tools;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Quentin Glineur (Obeo)
 *	Copies a project to another one with blazing its files
 */
public final class TransformProject {

	/**
	 * Prevents instanciation.
	 */
	private TransformProject() {
	}

	/**
	 * @param src source file (absolute)
	 * @param dest destination file path (absolute)
	 * @param baseDirectory (absolute)
	 */
	private static void cp(final String src, final String dest, final String baseDirectory) {
		File srcFile = new File(src);
		String srcRelativePath = srcFile.getAbsolutePath().substring(baseDirectory.length() + 1);
		File outFile = new File(dest + File.separator + srcRelativePath);
		if (srcFile.isDirectory()) {
			outFile.mkdir();
		} else {
			String[] args = {srcFile.getAbsolutePath(), outFile.getAbsolutePath()};
			BlazeBodyCode.main(args);
		}
	}

	/**
	 * @param baseFolder the folder to explore
	 * @return the list of sub elements paths
	 */
	private static List<String> explore(final String baseFolder) {
		File roamingFile = new File(baseFolder);
		List<String> result = new ArrayList<String>();
		String[] contents = roamingFile.list();
		for (int i = 0; i < contents.length; i++) {
			roamingFile = new File(baseFolder + File.separator + contents[i]);
			result.add(roamingFile.getAbsolutePath());
			if (roamingFile.isDirectory()) {
				result.addAll(TransformProject.explore(roamingFile.getAbsolutePath()));
			}
		}
		return result;
	}

	/**
	 * @param args base folder input and destination
	 */
	public static void main(final String[] args) {
		String baseFolder = args[0];
		String outContainer = args[1];
		for (String currentFile : TransformProject.explore(baseFolder)) {
			TransformProject.cp(currentFile, outContainer, baseFolder);
		}
	}

}
