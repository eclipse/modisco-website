This project is the core for Visual Basic injection (Text to model).

It is organized this way :

Under fr.obeo.reverse.vb stands the tools developed by Obeo
	for Visual Basic concepts recognition within the framework of
	the AMMA toolset along with other related tools.
	- In the "parser" folder, you will find a VB language metamodel expressed in KM3 (MM/vb.km3)
	- In the "build" folder, you will find the corresponding syntax expressed in ANTLR (vb.g)
	- In the tools, you will find two Java classes:
		"BlazeBodyCode" to copy a file marking source code before its parsing and
		"TransformProject" to copy an entire project calling "BlazeBodyCode"
			on every files

Under org.eclipse.gmt.tcs stands the TCS toolkit provided
	as the AMMA platform textual syntax expression mean.

The build folder is used to hold the result generated files
(the jar parser gotten by ANTLR compilation on the grammar file).
	
The ant file "VB_InjectorCreation.xml" is used to transform TCS into ANTLR file (.g)
and then to call ANTLR compilation on the generated files.

Notes:
The provided files have not been directly engineered by human means.
Rather, they have been gotten by transformation and adaptation.

Indeed, the goal is, of course to obtain structural informations
on Visual Basic 6 source code.
To hit the mark, Obeo has operated a transfer of a part of its knowledge
from its reverse engineering platform "Agility" to free tools.

Thus, ANTLR and therefore context free grammars, cannot express
all the "Agility" parsing power. That is why it needs to have the code of operations
marked previous to performing the parsing.

The result is a parser that does good job recovering the structure of simple projects
but won't analyze the inside of subs or functions.

Please feel free to fine-tune, customize and expand it for your needs !!!