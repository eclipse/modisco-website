/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.projectors;

/**
 * @author mikael
 *
 * @param <T>
 */
public class ProjectorFormalParameter<T> {
	 private boolean optionnal;
	 private T defaultValue;
	 private Class<T> type;
	 
	 /**
	 * @param type
	 */
	public ProjectorFormalParameter(Class<T> type) {
		 this(type, null);
	 }
	 
	 /**
	 * @param type
	 * @param defaultValue
	 */
	public ProjectorFormalParameter(Class<T> type, T defaultValue) {
		 this.type = type;
		 this.defaultValue = defaultValue;
		 this.optionnal = defaultValue != null;
	 }

	/**
	 * @return the defaultValue
	 */
	public T getDefaultValue() {
		return this.defaultValue;
	}
	
	/**
	 * @param o
	 * @return
	 * @throws IllegalArgumentException
	 */
	@SuppressWarnings("unchecked")
	public T checkType(Object o) throws IllegalArgumentException {
		if (this.type.equals(o.getClass())) {
			return (T)o;
		} else {
			throw new IllegalArgumentException("the type of the object is not a subtype of " + this.type);
		}
	}
	
	public Class<?> getType() {
		return this.type;
	}
	
	/**
	 * @return the optionnal
	 */
	public boolean isOptionnal() {
		return this.optionnal;
	}
	
	/**
	 * @param value
	 * @return
	 * @throws IllegalArgumentException
	 */
	public boolean checkConstraint(Object value) throws IllegalArgumentException {
		return true;
	}
}
