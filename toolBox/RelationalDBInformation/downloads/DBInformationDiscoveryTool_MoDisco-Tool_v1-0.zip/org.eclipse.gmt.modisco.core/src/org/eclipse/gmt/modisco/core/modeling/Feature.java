/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modeling;

/**
 * Interface of a reference model element feature. It provides
 * minimal common properties between all model handlers features.
 */
public interface Feature {

	/**
	 * Return the name of the feature.
	 * @return the name of the feature.
	 */
	public String getName();

	/**
	 * Tell if this feature is multi-valued.
	 * @return true if this feature is multi-valued, false otherwise.
	 */
	public boolean isMultiValued();

	/**
	 * Tell if this feature is a container.
	 * @return true if this feature is a container, false otherwise.
	 */
	public boolean isContainer();

	/**
	 * Return the owner of this feature.
	 * @return the owner of this feature.
	 */
	public ReferenceModelElement getOwner();

	/**
	 * Return the opposite feature of this feature
	 * @return the opposite feature of this feature of null if there is 
	 * none.
	 */
	public Feature getOpposite();

	/**
	 * Tell if the type of this feature is primitive.
	 * @return true if this feature's type is primitive, false otherwise.
	 */
	public boolean isPrimitive();

	/**
	 * Return the type of this feature.
	 * @return the model element typing this feature.
	 */
	public ModelElement getType();
}
