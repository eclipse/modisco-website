/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.projectors;

import java.util.Map;

import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;

/**
 * @author mikael
 *
 */
public abstract class Injector extends Projector {
	
	/**
	 * @param target
	 * @param source
	 * @param parameters
	 * @return
	 * @throws InjectorException
	 */
	public abstract ModelElement inject(Model target, Map<String, ProjectorActualParameter<?>> parameters) throws InjectorException;
}
