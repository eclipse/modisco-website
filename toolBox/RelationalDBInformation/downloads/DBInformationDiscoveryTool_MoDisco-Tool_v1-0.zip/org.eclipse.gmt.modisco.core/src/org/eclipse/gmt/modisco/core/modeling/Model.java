/*
 * Copyright (c) 2006, 2007 ATLAS.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	   Fr�d�ric Jouault 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.core.modeling;

import java.util.Collection;
import java.util.Set;

/**
 * Describes operation on the abstract notion of model. 
 */
public interface Model {

	/***
	 * Returns all elements conforming to the given reference model element.
	 * The reference model element has to belong to the reference model of this
	 * model.
	 * @param referenceModelElement the reference model element of all returned
	 * model element.
	 * @return all elements conforming to the given reference model element
	 */
	public Set<? extends ModelElement> getModelElementsByType(ReferenceModelElement referenceModelElement);
	
	/**
	 * Returns all elements conforming to the given reference model element or
	 * one of its subtypes.
	 * @param referenceModelElement the reference model element or the supertypes 
	 * of reference model elements of all returned model elements.
	 * @return all elements conforming to the given reference model element or
	 * one of its subtypes.
	 */
	public Set<? extends ModelElement> getModelElementsByKind(ReferenceModelElement referenceModelElement);
	
	/**
	 * Returns the reference model of this model.
	 * @return the reference model of this model. 
	 */
	public ReferenceModel getReferenceModel();
	
	/**
	 * Creates a new model element at the root of this model (i.e. after the call
	 * of createModelElement(), the returned model element belongs to this.getContents().
	 * @param referenceModelElement the reference model element of the model element to
	 * create. It has to belong to the reference model of this model.
	 * @return the newly created model element.
	 */
	public ModelElement createModelElement(ReferenceModelElement referenceModelElement);
	
	/**
	 * Returns the direct contents of this model.
	 * @return a collection of model element directly contained by this model.  
	 */
	public Collection<? extends ModelElement> getContents();
}
