/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.projectors;

/**
 * @author mikael
 *
 */
public class ProjectorException extends Exception {

	private static final long serialVersionUID = -322899514984565626L;

	/**
	 * 
	 */
	public ProjectorException() {
		super();
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ProjectorException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * @param arg0
	 */
	public ProjectorException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public ProjectorException(Throwable arg0) {
		super(arg0);
	}

}
