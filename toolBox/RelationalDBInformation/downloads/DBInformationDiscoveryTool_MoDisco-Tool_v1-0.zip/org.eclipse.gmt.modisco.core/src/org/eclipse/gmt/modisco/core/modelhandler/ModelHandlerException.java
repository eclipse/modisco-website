/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modelhandler;

/**
 * An exception occuring during model handling.
 *
 */
public class ModelHandlerException extends Exception {

	private static final long serialVersionUID = 8688508084644139656L;
	
	/**
	 * Constructs a new exception with <code>null</code> as its detail message.
	 */
	public ModelHandlerException() {
		super();
	}

	/**
	 * Constructs a new exception with the specified detail message 
	 * and cause. 
	 * 
	 * Note that the detail message associated with <code>cause</code> is <i>not</i> 
	 * automatically incorporated in this exception's detail message. 
	 * @param arg0 the detail message. The detail message is saved 
	 * for later retrieval by the {@link Throwable.getMessage()} method.
	 * @param arg1 the cause (which is saved for later retrieval by the 
	 * @link{Throwable.getCause()} method). (A null value is permitted, 
	 * and indicates that the cause is nonexistent or unknown.)
	 */
	public ModelHandlerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * Constructs a new exception with the specified detail message.
	 * @param arg0 the detail message. The detail message is saved 
	 * for later retrieval by the {@link Throwable.getMessage()} method.
	 */
	public ModelHandlerException(String arg0) {
		super(arg0);
	}

	/**
	 * Constructs a new exception with the specified cause and a detail 
	 * message of <code>(cause==null ? null : cause.toString())</code> (which 
	 * typically contains the class and detail message of <code>cause</code>). 
	 * This constructor is useful for exceptions that are little more 
	 * than wrappers for other throwables (for example, PrivilegedActionException).
	 * @param arg0 the cause (which is saved for later retrieval by the 
	 * @link{Throwable.getCause()} method). (A null value is permitted, 
	 * and indicates that the cause is nonexistent or unknown.)
	 */
	public ModelHandlerException(Throwable arg0) {
		super(arg0);
	}
}
