/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modeling.projectors;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.eclipse.gmt.modisco.core.modeling.Feature;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ModelingException;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModelElement;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.ExtractorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.core.projectors.ProjectorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorFormalParameter;

public class XMIExtractor extends Extractor {
	
	private static XMIExtractor INSTANCE;
	
	private Model source;
	private PrintStream target;
	private Map<ModelElement, String> idByModelElement;
	private int nextId;

	private String indent;
	private String indentString;
	private boolean isClosed;
	private boolean isIndented;
	private boolean hasContents;

	private XMIExtractor() {
		this.getFormalParameters().put("printStream", 
				new ProjectorFormalParameter<PrintStream>(PrintStream.class) {
					@Override
					public boolean checkConstraint(Object o) throws IllegalArgumentException {
						PrintStream value = this.checkType(o);
						return (value != null);
				}});
		this.getFormalParameters().put("indentString", 
			new ProjectorFormalParameter<String>(String.class, "  ") {
				@Override
				public boolean checkConstraint(Object o) throws IllegalArgumentException {
					String value = this.checkType(o);	
					boolean checked = (value.trim().length() == 0);
					if (!checked) {
						throw new IllegalArgumentException();
					} 
					return checked;
			}});
		this.getFormalParameters().put("XMIVersion", 
			new ProjectorFormalParameter<String>(String.class) {
				@Override
				public boolean checkConstraint(Object o) throws IllegalArgumentException {
					String value = this.checkType(o);
					boolean checked =  (value.equals("1.1") ||
										value.equals("1.2") ||
										value.equals("2.0") || 
										value.equals("2.1"));
					if (!checked) {
						throw new IllegalArgumentException();
					} 
					return checked;
			}});
		this.getFormalParameters().put("namespace", 
			new ProjectorFormalParameter<String>(String.class));
		this.getFormalParameters().put("useUUID", 
			new ProjectorFormalParameter<Boolean>(Boolean.class, true));
	}

	public static Extractor getInstance() {
		if (XMIExtractor.INSTANCE == null) {
			XMIExtractor.INSTANCE = new XMIExtractor();
		}
		return XMIExtractor.INSTANCE;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.projectors.Extractor#extract(org.eclipse.gmt.modisco.core.modeling.Model, java.lang.Object, java.util.Map)
	 */
	@Override
	public void extract(Model source, Map<String, ProjectorActualParameter<?>> params) throws ExtractorException {
		try {
			this.checkParameters(params);
		} catch (ProjectorException e) {
			throw new ExtractorException(e.getMessage());
		}
		
		this.source = source;
		this.target = (PrintStream)this.getActualParameters().get("printStream").getValue();
		this.indent = "";
		this.isClosed = true;
		this.idByModelElement = new HashMap<ModelElement, String>();
		this.nextId = 1;
		this.isIndented = false;
		this.indentString = (String)this.getActualParameters().get("indentString").getValue();
		
		try {
			if (((String)this.getActualParameters().get("XMIVersion").getValue()).charAt(0) == '2') {
				this.write2();
			} else {
				this.write1();
			}
		} catch (ModelingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void write2() throws ModelingException {
		if(this.source.getContents().size() != 1) {
			this.start("xmi:XMI");
			this.attr("xmi:version", (String)this.getActualParameters().get("XMIVersion").getValue());
			this.attr("xmlns:xmi", "http://www.omg.org/XMI");
			this.attr("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
			this.attr("xmlns", (String)this.getActualParameters().get("namespace").getValue());
	
			for (Object element : this.source.getContents()) {
				ModelElement e = (ModelElement)element;
				ReferenceModelElement m = e.getReferenceModelElement();
				this.start(m.getName());
				this.write2(e);
				this.end(m.getName());
			}
			this.end("xmi:XMI");			
		} else {
			ModelElement e = this.source.getContents().iterator().next();
			ReferenceModelElement m = e.getReferenceModelElement();
			this.start(m.getName());
			this.attr("xmi:version", (String)this.getActualParameters().get("XMIVersion").getValue());
			this.attr("xmlns:xmi", "http://www.omg.org/XMI");
			this.attr("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
			this.attr("xmlns", (String)this.getActualParameters().get("namespace").getValue());
			this.write2(e);
			this.end(m.getName());			
		}

		this.target.close();
	}
	
	private String id(ModelElement e) {
		String ret = this.idByModelElement.get(e);
		
		if(ret == null) {
			if ((Boolean)this.getActualParameters().get("useUUID").getValue()) {
				ret = UUID.randomUUID().toString();
			} else {
				ret = "a" + this.nextId;
				this.nextId++;
				this.idByModelElement.put(e, ret);
			}
		}
		
		return ret;
	}
	
	private void write2(ModelElement e) throws ModelingException {
		ReferenceModelElement m = e.getReferenceModelElement();

		this.attr("xsi:type", m.getName());
		this.attr("xmi:id", this.id(e));

		Collection<Feature> nestedFeatures = new ArrayList<Feature>();
		for (Object element : m.getFeatures()) {
			Feature f = (Feature)element;
			if(f.isContainer() || (f.isMultiValued() && f.isPrimitive())) {
				nestedFeatures.add(f);
			} else {
				if(f.isMultiValued()) {	// && !f.isPrimitive()
					Collection v = (Collection)e.get(f.getName());
					String value = "";
					for(Iterator j = v.iterator() ; j.hasNext() ; ) {
						if(value.length() > 0) {
							value += " ";
						}
						value += this.id((ModelElement)j.next());
					}
					this.attr(f.getName(), value);
				} else if((f.getOpposite() != null) && f.getOpposite().isContainer()) {
					// not necessary to print
				} else {
					Object v = e.get(f.getName());
					if(v != null) {
						String value = "undefined";
						if(f.isPrimitive()) {
							value = v.toString();
						} else {
							value = this.id((ModelElement)v);
						}
						this.attr(f.getName(), value);
					}
				}
			}
		}
		for (Object element : nestedFeatures) {
			Feature f = (Feature)element;
			if(f.isMultiValued()) {
				for(Iterator j = ((Collection)e.get(f.getName())).iterator() ; j.hasNext() ; ) {
					Object v = j.next();
					this.start(f.getName());
					if(f.isPrimitive()) {
						this.text(v.toString());
					} else {
						this.write2((ModelElement)v);
					}
					this.end(f.getName());
				}
			} else {	// !isPrimitive
				ModelElement v = (ModelElement)e.get(f.getName());
				if(v != null) {
					this.start(f.getName());
					this.write2(v);
					this.end(f.getName());
				}
			}
		}
			
	}
	
	private void write1() throws ModelingException {
		this.target.println("<?xml version='1.0' encoding='UTF-8' ?>");

		this.start("XMI");
		this.attr("xmi.version", "1.2");
		//this.attr("xmlns:" + (String)this.getActualParameters().get("namespace").getValue(), (String)this.getActualParameters().get("namespace").getValue());

		this.start("XMI.header");
		this.start("XMI.documentation");
		
		this.start("XMI.exporter");
		this.text("MoDisco XMI Writer");
		this.end("XMI.exporter");
		
		this.start("XMI.exporterVersion");
		this.text("1.0");
		this.end("XMI.exporterVersion");
		
		this.start("XMI.metaModelVersion");
		this.text("");
		this.end("XMI.metaModelVersion");
				
		this.end("XMI.documentation");
		this.end("XMI.header");
		
		this.start("XMI.content");

		for (Object element : this.source.getContents()) {
			ModelElement e = (ModelElement)element;
			this.write1(e);
		}
		
		this.end("XMI.content");
		this.end("XMI");			

		this.target.close();
	}
	
	private void write1(ModelElement e) throws ModelingException {
		ReferenceModelElement m = e.getReferenceModelElement();

		this.start((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName());
		this.attr("xmi.id", this.id(e));

		Collection<Feature> nestedFeatures = new ArrayList<Feature>();
		Collection<Feature> refFeatures = new ArrayList<Feature>();
		for (Feature f : m.getFeatures()) {
			if(f.isContainer() || (f.isMultiValued() && f.isPrimitive())) {
				nestedFeatures.add(f);
			} else {
				if(f.isMultiValued()) {	//
					if (f.isPrimitive()) {
						Collection v = (Collection)e.get(f.getName());
						String value = "";
						for(Iterator j = v.iterator() ; j.hasNext() ; ) {
							if(value.length() > 0) {
								value += " ";
							}
							value += this.id((ModelElement)j.next());
						}
						this.attr(f.getName(), value);
					} else {
						Collection v = (Collection)e.get(f.getName());
	
						if (v.size() > 0) {
							this.start((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName() + "." + f.getName());
							for(Iterator j = v.iterator() ; j.hasNext() ; ) {
								this.start((String)this.getActualParameters().get("namespace").getValue() + "." + f.getOwner().getName());
								this.attr("xmi.idref", this.id((ModelElement)j.next()));
								this.end((String)this.getActualParameters().get("namespace").getValue() + "." + f.getOwner().getName());
							}
							this.end((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName() + "." + f.getName());
						}
					}
				} else if((f.getOpposite() != null) && f.getOpposite().isContainer()) {
					// not necessary to print
				} else {
					Object v = e.get(f.getName());
					if(v != null) {
						if(f.isPrimitive()) {
							this.attr(f.getName(), v.toString());
						} else {
							refFeatures.add(f);
						}
						
					}
				}
			}
		}
		
		for (Feature f: refFeatures) {
			this.start((String)this.getActualParameters().get("namespace").getValue() + "." + f.getOwner().getName() + "." + f.getName());
			this.start((String)this.getActualParameters().get("namespace").getValue() + "." + ((ModelElement)e.get(f.getName())).getReferenceModelElement().getName());
			this.attr("xmi.idref", this.id((ModelElement)e.get(f.getName())));
			this.end((String)this.getActualParameters().get("namespace").getValue() + "." + ((ModelElement)e.get(f.getName())).getReferenceModelElement().getName());
			this.end((String)this.getActualParameters().get("namespace").getValue() + "." + f.getOwner().getName() + "." + f.getName());
		}
		
		for (Object element : nestedFeatures) {
			Feature f = (Feature)element;
			if(f.isMultiValued()) {
				this.start((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName() + "." + f.getName());
				for(Iterator j = ((Collection)e.get(f.getName())).iterator() ; j.hasNext() ; ) {
					Object v = j.next();
					if(f.isPrimitive()) {
						this.text(v.toString());
					} else {
						this.write1((ModelElement)v);
					}
				}
				this.end((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName() + "." + f.getName());
			} else {	// !isPrimitive
				ModelElement v = (ModelElement)e.get(f.getName());
				if(v != null) {
					this.start(f.getName());
					this.write1(v);
					this.end(f.getName());
				}
			}
		}
		
		this.end((String)this.getActualParameters().get("namespace").getValue() + "." + m.getName());
	}
	
	private static final Collection<Character> escapeForAttribute = new HashSet<Character>();
	{
		XMIExtractor.escapeForAttribute.add(new Character('\n'));
		XMIExtractor.escapeForAttribute.add(new Character('<'));
		XMIExtractor.escapeForAttribute.add(new Character('>'));
		XMIExtractor.escapeForAttribute.add(new Character('\"'));
		XMIExtractor.escapeForAttribute.add(new Character('\''));
		XMIExtractor.escapeForAttribute.add(new Character('&'));
	}
	
	private void attr(String name, String value) {
		if(this.isClosed) {
			throw new UnsupportedOperationException("cannot serialize an attribute if no ModelElement is open");
		}
		String oldValue = value;
		value = "";
		for(int i = 0 ; i < oldValue.length() ; i++) {
			char c = oldValue.charAt(i);
			if(!XMIExtractor.escapeForAttribute.contains(new Character(c))) {
				value += c;
			} else {
				value += "&#" + (int)c + ";";
			}
		}
		this.target.print(" " + name + "=\"" + value + "\"");
	}
	
	private void text(String value) {
		if(!this.isClosed) {
			this.target.print(">");
			this.isClosed = true;
			this.isIndented = false;
		}
		this.target.print(value);
		this.hasContents = true;
	}
	
	private void close() {
		this.target.println(">");
		this.indent += this.indentString;
		this.isClosed = true;
		this.isIndented = true;
	}

	private void start(String name) {
		if(!this.isClosed) {
			this.close();
		}
		this.target.print(this.indent + "<" + name);
		this.isClosed = false;
		this.hasContents = false;
		this.isIndented = false;
	}
	
	private void end(String name) {
		if(!this.hasContents) {
			this.target.println("/>");			
		} else {
			if(!this.isClosed) {
				this.close();
			}
			if(this.isIndented) {
				if(this.indent.length() > 0) {
					this.indent = this.indent.substring(0, this.indent.length() - this.indentString.length());
				}
				this.target.print(this.indent);
			}
			this.target.println("</" + name + ">");
		}
		this.isClosed = true;
		this.hasContents = true;
		this.isIndented = true;
	}
}
