/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modelhandler;

import java.util.Map;

import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;

/**
 * A model handler is a framework for handling models. Examples of model 
 * handlers are EMF, MDR, etc. This interface has to be implemented for 
 * supporting models creation, load and save. Concrete implementations have 
 * to do everything needed in the constructor to initialize the model 
 * handler.     
 */
public interface ModelHandler {
	
	/**
	 * Tell if this model handler is supporting this kinds of model.
	 * @param model the model to be tested.
	 * @return true if this model handler is handling the model, false
	 * otherwise.
	 */
	public abstract boolean isHandling(Model model);
	
	/**
	 * Create a new empty model conforming to the reference model 
	 * given in parameter. 
	 * @param referenceModel the reference model of the model to 
	 * create. 
	 * @return the newly empty created model.
	 */
	public abstract Model createModel(ReferenceModel referenceModel);
		
	/**
	 * Save the model given as first parameter regarding the extractor.
	 * The given model has to be handled by this model handler. The 
	 * extractor has to be supported by this model handler. Parameters
	 * has to be specific to the extractor.
	 * @param model the model to save.
	 * @param extractor the extractor to use for saving.
	 * @param parameters the parameters of the extractor.
	 */
	public abstract void saveModel(final Model model, Extractor extractor, Map<String, ProjectorActualParameter<?>> parameters);
		
	/**
	 * Load a model conforming to the reference model with the given injector.
	 * The reference model has to be handled by this model handler. 
	 * Parameters has to be specific to the injector.
	 * @param referenceModel the reference model of the model to be load.
	 * @param injector the injector to use for loading
	 * @param parameters the parameters of the injector.
	 * @return
	 */
	public abstract Model loadModel(ReferenceModel referenceModel, Injector injector, Map<String, ProjectorActualParameter<?>> parameters);
	
	/**
	 * Dispose all resources of this model. The given model has to
	 * be handled by this model handler.
	 * @param model the model to dispoe.
	 */
	public abstract void closeModel(Model model);
}
