/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modeling;

import java.util.Collection;

/**
 * A model element belong to a model. It has some properties 
 * describes by its reference model element's features.
 */
public interface ModelElement {
	
	public static String UNNAMED = "<unnamed>";
	public static String NOT_NAMED_YET = "<notnamedyet>";
	public static String CONTAINMENT_SEPARATOR = "::";
	
	public Model getModel();

	/**
	 * Navigates mu.
	 * @return the metaelement of the current element.
	 */
	public ReferenceModelElement getReferenceModelElement();
	
	/**
	 * Returns the value of the property with the given name.
	 * @param propertyName the name of the property to get.
	 * Reference model element has to have feature with this 
	 * name.
	 * @return the value of the property
	 * @throws java.lang.IllegalArgumentException if the property
	 * is not one the reference model element's features.
	 */
	public Object get(String propertyName);

	/**
	 * Sets the value of the given property with the given 
	 * object to the new value.
	 * If the property is multi-valued, the new value must be an Collection 
	 * and each object in that collection must be an instance of the property's 
	 * type; the existing contents are cleared and the contents of the new 
	 * value are added. If the property is single-valued, the new value 
	 * directly must be an instance of the feature's type and it becomes 
	 * the new value of the property of the object. 
	 * @param propertyName
	 * @param value
	 * @throws java.lang.IllegalArgumentException if the property
	 * is not one the reference model element's features.
	 * @throws java.lang.ClassCastException if there is a type conflict. 
	 */
	public void set(String propertyName, Object value);
	
	/**
	 * If the property is multi-valued, unset is equivalent to 
	 * <code>set(propertyName, Collections.EMPTY_LIST)</code>. If the
	 * property is single valued, is is equivalent to
	 * <code>set(propertyName, null)</code>.
	 * @param propertyName
	 */
	public void unset(String propertyName);
		
	/**
	 * Adds the value to the property's list with the given name.
	 * The property has to be multi-valued and the given value
	 * has to be of the same type as the feature's type.
	 * @param propertyName the name of the multi-valued property
	 * @param value the new value to add to the property's list
	 * @throws java.lang.IllegalArgumentException if the property
	 * is not one the reference model element's features.
	 * @throws java.lang.ClassCastException if there is a type conflict.
	 */
	public void add(String propertyName, Object value);
	
	/**
	 * The property must be multi-valued. It removes the object value
	 * from the list of the property. The object has to be from the type
	 * of the feature.
	 * @param propertyName the multi-valued property to modified
	 * @param value the value to remove
	 * @throws java.lang.IllegalArgumentException if the property
	 * is not one the reference model element's features.
	 * @throws java.lang.ClassCastException if there is a type conflict. 
	 */
	public void remove(String propertyName, Object value);
	
	/**
	 * Tells if this model element has the given reference model element
	 * as reference model element or one of its subtypes. 
	 * @param referenceModelElement the reference model element to be checked
	 * @return true if this model element has the given reference model element
	 * or one of its subtypes as reference model element.
	 */
	public boolean isKindOf(ReferenceModelElement referenceModelElement);
	
	/**
	 * Tells if this model element has the given reference model element
	 * as reference model element.
	 * @param referenceModelElement the reference model element to be checked
	 * @return true if this model element has the given reference model element
	 * as reference model element. 
	 */
	public boolean isTypeOf(ReferenceModelElement referenceModelElement);
	
	/**
	 * Returns the immediate container of this model element.
	 * @return the immediate container of this model element or null if 
	 * it is top level.
	 */
	public ModelElement getContainer();
	
	/**
	 * Returns the direct contents of this model element.
	 * @return the possibly empty collection of model element being directly 
	 * contained by this model element. 
	 */
	public Collection<? extends ModelElement> getContents();
}
