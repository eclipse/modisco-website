/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.projectors;

/**
 * @author mikael
 *
 */
public class ExtractorException extends ProjectorException {

	private static final long serialVersionUID = -363664586965867058L;

	/**
	 * 
	 */
	public ExtractorException() {
		super();
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ExtractorException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * @param arg0
	 */
	public ExtractorException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public ExtractorException(Throwable arg0) {
		super(arg0);
	}
}
