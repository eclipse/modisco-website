/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modeling;

/**
 * 
 */
public class SimpleFeature implements Feature {

	private ReferenceModelElement owner;

	private String name;

	private boolean isMultiValued;

	private boolean isContainer;

	private Feature opposite;

	private boolean isPrimitive;

	private ModelElement type;

	/**
	 * @param owner
	 * @param name
	 * @param isMultiValued
	 * @param isContainer
	 * @param isPrimitive
	 * @param type
	 */
	public SimpleFeature(ReferenceModelElement owner, String name,
			boolean isMultiValued, boolean isContainer, boolean isPrimitive,
			ModelElement type) {
		this.owner = owner;
		this.name = name;
		this.isMultiValued = isMultiValued;
		this.isContainer = isContainer;
		this.isPrimitive = isPrimitive;
		this.type = type;
	}

	/**
	 * @param opposite
	 */
	public void setOpposite(Feature opposite) {
		this.opposite = opposite;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#getName()
	 */
	public String getName() {
		return this.name;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#isMultiValued()
	 */
	public boolean isMultiValued() {
		return this.isMultiValued;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#getOwner()
	 */
	public ReferenceModelElement getOwner() {
		return this.owner;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#getOpposite()
	 */
	public Feature getOpposite() {
		return this.opposite;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#isContainer()
	 */
	public boolean isContainer() {
		return this.isContainer;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#isPrimitive()
	 */
	public boolean isPrimitive() {
		return this.isPrimitive;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modeling.Feature#getType()
	 */
	public ModelElement getType() {
		return this.type;
	}
}
