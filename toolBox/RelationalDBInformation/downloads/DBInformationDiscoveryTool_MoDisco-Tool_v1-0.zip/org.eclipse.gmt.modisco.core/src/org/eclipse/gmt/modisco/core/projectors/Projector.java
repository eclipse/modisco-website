/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.projectors;

import java.util.HashMap;
import java.util.Map;

/**
 * @author mikael
 *
 */
public abstract class Projector {
	
	private final Map<String, ProjectorFormalParameter<?>> formalParameters = new HashMap<String, ProjectorFormalParameter<?>>();

	private Map<String, ProjectorActualParameter<?>> actualParameters;
	
	/**
	 * @return
	 */
	public Map<String, ProjectorFormalParameter<?>> getFormalParameters() {
		return this.formalParameters;
	}
	
	/**
	 * @return
	 */
	protected Map<String, ProjectorActualParameter<?>> getActualParameters() {
		if (this.actualParameters == null) {
			this.actualParameters = new HashMap<String, ProjectorActualParameter<?>>();
		}
		return this.actualParameters;
	}
	
	/**
	 * @param params
	 * @throws ProjectorException
	 */
	protected void checkParameters(Map<String, ProjectorActualParameter<?>> params) throws ProjectorException {
		for (String name : this.getFormalParameters().keySet()) {
			if (params.get(name) == null) {
				if (!this.getFormalParameters().get(name).isOptionnal()) {
					throw new ProjectorException("parameter \"" + name + "\" is mandatory for " + this.getClass().getSimpleName());
				} else {
					this.getActualParameters().put(name, new ProjectorActualParameter<Object>(this.getFormalParameters().get(name).getDefaultValue()));
				}
			} else {
				try {
					this.getFormalParameters().get(name).checkConstraint(params.get(name).getValue());
					this.getActualParameters().put(name, params.get(name));
				} catch (IllegalArgumentException e) {
					throw new ProjectorException("the type and/or the value of parameter \"" + name + "\" is invalid for " + this.getClass().getSimpleName());
				}
			}
		}
		
		for (String name : params.keySet()) {
			if (this.getFormalParameters().get(name) == null) {
				throw new ExtractorException("unrecognized parameter \"" + name + "\" for " + this.getClass().getSimpleName());
			}
		}
	}
}
