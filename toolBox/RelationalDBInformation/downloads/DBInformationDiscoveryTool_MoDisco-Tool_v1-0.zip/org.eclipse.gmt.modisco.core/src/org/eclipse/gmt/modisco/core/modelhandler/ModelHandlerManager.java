/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modelhandler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.gmt.modisco.core.modeling.Model;

/**
 * This class provide a very simple management of model handlers.
 * It allows to get a model handler for a specific model.
 * This class implement a singleton pattern.
 */
public class ModelHandlerManager {
	private Map<String, ModelHandler> registeredModelHandlers;
	private static ModelHandlerManager INSTANCE;
	
	/**
	 * Creates a new empty model handler manager. 
	 */
	protected ModelHandlerManager() {
		this.registeredModelHandlers = new HashMap<String, ModelHandler>();
	}
	
	/**
	 * Returns the sole instance of model handler manager
	 * @return model handler manager instance.
	 */
	public static ModelHandlerManager getInstance() {
		if (ModelHandlerManager.INSTANCE == null) {
			ModelHandlerManager.INSTANCE = new ModelHandlerManager();
		}
		return ModelHandlerManager.INSTANCE;
	}
	
	/**
	 * Returns the model handler with a given name.
	 * @param modelHandlerName the name of the model handler.
	 * @return the model handler with the given name or null
	 * if it does not exist.
	 */
	public ModelHandler getModelHandlerByName(String modelHandlerName) {
		ModelHandler ret = null;
		ret = this.registeredModelHandlers.get(modelHandlerName);
		return ret;	
	}

	/**
	 * Returns the possibly empty collection of model handlers handling this model.
	 * @param model the model which we want the model handler.
	 * @return the collection of model handlers handling the model. An empty set
	 * means there is no model handler handling this model.
	 */
	public Collection<ModelHandler> getModelHandler(Model model) {
		Collection<ModelHandler> ret = new ArrayList<ModelHandler>();
		for(ModelHandler modelHandler : ModelHandlerManager.getInstance().getModelHandlers()) {
			if(modelHandler.isHandling(model)) {
				ret.add(modelHandler);
			}
		}
		return ret;
	}
	
	/**
	 * Returns the possibly empty collection of model handler name handling this model
	 * @param model the model which we want the model handler.
	 * @return the collection of model handlers names handling the model. An empty set
	 * means there is no model handler handling this model.
	 */
	public Collection<String> getModelHandlerName(Model model) {
		Collection<String> ret = new ArrayList<String>();
		for(String modelHandlerName : ModelHandlerManager.getInstance().getModelHandlersNames()) {
			if(this.getModelHandlerByName(modelHandlerName).isHandling(model)) {
				ret.add(modelHandlerName);
			}
		}
		return ret;
	}
	
	/**
	 * Adds a model handler to the manager with the given name
	 * @param name the name of the model handler
	 * @param modelHandler the model handler to add to the manager.
	 */
	public void putModelHandler(String name, ModelHandler modelHandler) {
		this.registeredModelHandlers.put(name, modelHandler);
	}

	/**
	 * Returns all the previously registered model handlers.
	 * @return the collection of registered model handlers.
	 */
	public Collection<ModelHandler> getModelHandlers() {
		return this.registeredModelHandlers.values();
	}

	/**
	 * Returns all the previously registered model handlers' 
	 * names.
	 * @return the collection of registered model handlers' 
	 * name.
	 */
	public Set<String> getModelHandlersNames() {
		return this.registeredModelHandlers.keySet();
	}

	/**
	 * Returns the map of registered model handlers's name and 
	 * their instances.
	 * @return the registererd model handlers.
	 */
	protected Map<String, ModelHandler> getRegisteredModelHandlers() {
		return this.registeredModelHandlers;
	}
}
