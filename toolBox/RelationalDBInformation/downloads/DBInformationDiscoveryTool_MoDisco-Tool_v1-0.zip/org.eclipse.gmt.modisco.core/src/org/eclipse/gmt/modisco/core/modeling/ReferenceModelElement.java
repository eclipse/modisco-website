/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 *     Fr�d�ric Jouault
 * 
 */

package org.eclipse.gmt.modisco.core.modeling;

import java.util.Collection;

/**
 * 
 * A metamodel element that can be the target of mu.
 * 
 * @author jouault
 *
 */
public interface ReferenceModelElement extends ModelElement {
	
	/**
	 * @param other
	 * @return
	 */
	public boolean isA(ReferenceModelElement other);

	/**
	 * @return
	 */
	public String getName();
	
	/**
	 * @param name
	 * @return
	 */
	public Feature getFeature(String name);
	
	/**
	 * @return
	 */
	public Collection<? extends Feature> getFeatures();
}
