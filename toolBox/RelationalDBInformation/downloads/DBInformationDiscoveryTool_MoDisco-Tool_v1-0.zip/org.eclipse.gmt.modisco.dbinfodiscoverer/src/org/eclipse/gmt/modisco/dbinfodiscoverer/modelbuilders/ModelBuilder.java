/*
 * Copyright (c) 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders;


import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;

/**
 * Model builder abstract class
 * @author Hugo Bruneliere
 */
public abstract class ModelBuilder {
	
	private ModelHandler modelhandler;
	private ReferenceModel metamodel;
	private Model currentModel;
	
	/**
	 * 
	 */
	public ModelBuilder(ModelHandler mh, ReferenceModel metametamodel, Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> params) {
		super();
		this.modelhandler = mh;
		this.metamodel = (ReferenceModel) this.modelhandler.loadModel(metametamodel, metamodelInjector, params);
		this.currentModel = null;
	}
			
	/**
	 * @return the currentModel
	 */
	public Model getCurrentModel() {
		return this.currentModel;
	}

	/**
	 * @return the metamodel
	 */
	public ReferenceModel getMetamodel() {
		return this.metamodel;
	}
	
	/**
	 * @return the model handler
	 */
	public ModelHandler getModelHandler() {
		return this.modelhandler;
	}

	public void initNewModel(String modelName) {
		System.out.println("Initialization of the \""+modelName+"\" new model");
		this.currentModel = this.modelhandler.createModel(this.metamodel);
	}
	
	public void save(Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> params) {
		if( this.currentModel!= null) {
			System.out.println("Saving of the current model");
			this.modelhandler.saveModel(this.currentModel, modelExtractor, params);
		}
	}
	
}
