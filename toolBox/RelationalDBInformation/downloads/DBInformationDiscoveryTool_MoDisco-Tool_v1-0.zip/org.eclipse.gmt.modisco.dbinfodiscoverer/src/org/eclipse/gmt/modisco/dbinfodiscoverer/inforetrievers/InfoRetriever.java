/*
 * Copyright (c) 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers;

import java.util.Map;

import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders.ModelBuilder;

/**
 * Information retriever abstract class
 * @author Hugo Bruneliere
 */
public abstract class InfoRetriever {

	private ModelBuilder modelBuilder;

	/**
	 * 
	 */
	public InfoRetriever(ModelBuilder modelBuilder) {
		super();
		this.modelBuilder=modelBuilder;
	}
		
	/**
	 * @return the modelBuilder
	 */
	public ModelBuilder getModelBuilder() {
		return modelBuilder;
	}

	public abstract void discover(Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams);
	
}
