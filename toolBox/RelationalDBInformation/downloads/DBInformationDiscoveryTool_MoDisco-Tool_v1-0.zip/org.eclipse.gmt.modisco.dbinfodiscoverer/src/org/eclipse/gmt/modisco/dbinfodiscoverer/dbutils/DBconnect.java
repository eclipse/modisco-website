package org.eclipse.gmt.modisco.dbinfodiscoverer.dbutils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;


/**
 * Utility class for managing databases in Java program using JDBC.
 * @author Hugo Bruneliere
 */
public class DBconnect
{
	static final String EXE="Execution of: ";
	static final String ERR="Error in: ";
	
	private String driverName="";
	private String url="";
	private String user="";
	private String password="";
	private String baseName="";
	private Connection connection=null;
	
    /*
	public static void main(String[] args)
	{
		System.out.println("Programme de test\n");
		try
		{
			DBconnect dbcon = new DBconnect("oracle.jdbc.driver.OracleDriver","jdbc:oracle:thin:@quad:1521:ORCL","l02","hlgbf");
			dbcon.loadDriver();
			dbcon.connectTo("notreBase");
			//dbcon.createDataBase("essaiBase");
			//dbcon.disconnect();
			//dbcon.connectTo("essaiBase");
			
			dbcon.createTable("prov",new String[]{"att1","att2","att3"},
									 new String[]{"varchar(2)","varchar(2)","varchar(2)"});
			dbcon.insertIntoTable("prov", new String[]{"att1","att2","att3"},
										  new String[]{"'a1'","'b1'","'c1'"});
			dbcon.insertIntoTable("prov", new String[]{"att1","att2","att3"},
										  new String[]{"'a2'","'b2'","'c2'"});
			dbcon.insertIntoTable("prov", new String[]{"att1","att2","att3"},
										  new String[]{"'a3'","'b3'","'c3'"});
			dbcon.createTable("prov2",new String[]{"att11","att21","att31"},
									 new String[]{"varchar(2)","varchar(2)","varchar(2)"});
			dbcon.insertIntoTable("prov2", new String[]{"att11","att21","att31"},
										  new String[]{"'a1'","'b1'","'c1'"});
			dbcon.insertIntoTable("prov2", new String[]{"att11","att21","att31"},
										  new String[]{"'a2'","'b2'","'c2'"});
			dbcon.insertIntoTable("prov2", new String[]{"att11","att21","att31"},
										  new String[]{"'a3'","'b3'","'c3'"});
			String jointure="SELECT a.att2, b.att31 FROM prov a, prov2 b WHERE a.att1=b.att11";
			dbcon.execSQL_Query(jointure); 
										  
			dbcon.selectFromTable("prov", new String[]{}, new String[]{}, new String[]{});
			dbcon.selectFromTable("prov", new String[]{"att1"}, 
										  new String[]{"att2"}, new String[]{"'b3'"});
			dbcon.updateTable("prov", new String[]{"att1"}, new String[]{"'a8'"},
									  new String[]{"att2"}, new String[]{"'b2'"});
			dbcon.updateTable("prov", new String[]{"att3"}, new String[]{"'c'"},
									  new String[]{}, new String[]{});
			dbcon.deleteFromTable("prov", new String[]{"att1"}, new String[]{"'a3'"});
			dbcon.deleteFromTable("prov", new String[]{}, new String[]{});
		    			
		        dbcon.dropTable("prov");
	        	dbcon.dropTable("prov2");
			//dbcon.disconnect();
			//dbcon.connectTo("?????");
			//dbcon.dropDataBase("essaiBase");
			dbcon.disconnect();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	*/
	/*-----------------------------------------------------------------------------------*/
	
	/**
	 * @return the baseName
	 */
	public String getBaseName() {
		return baseName;
	}

	/**
	 * @return the connexion
	 */
	public Connection getConnection() {
		return connection;
	}

	/**
	 * @return the driverName
	 */
	public String getDriverName() {
		return driverName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	public DBconnect(String driverName, String databaseServerUrl)
	{
		this.driverName=driverName; this.url=databaseServerUrl;
		this.user=""; this.password="";
	}
	
	public void loadDriver()
	{
		String methode="Loading of the driver";
		try 
		{
			Class.forName(this.driverName).newInstance();
			System.out.println(EXE + methode + " " + driverName);
		}
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(ERR + methode + " -> " + cnfe.getMessage() );
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	public void connectTo(String baseName, String user, String password)
	{
		this.user=user; this.password=password;
		String methode="Connection to the database";
		try
		{
			if(connection!=null) disconnect();
			String dbUrl=this.url+"/"+baseName;
			connection=DriverManager.getConnection(dbUrl,this.user,this.password);
			this.baseName=baseName;
			System.out.println(EXE + methode + "  \"" + baseName + "\" on \"" + this.url + "\"");		
		}
		catch(SQLException e)
		{
			System.out.println(ERR + methode + " \"" + baseName + "\" on \"" + this.url + "\" -> " + e.getMessage() );
			System.exit(1);
		}
	}
	
	public void disconnect()
	{
		String methode="Disconnection from the database";
		try
		{
			connection.close(); 
			System.out.println(EXE + methode + "  \"" + this.baseName + "\" on \"" + this.url + "\"");
			connection=null; this.baseName="";
		}
		catch(SQLException e)
		{
			System.out.println(ERR + methode + "  \"" + this.baseName + "\" on \"" + this.url + "\" -> " + e.getMessage() );
		}
	}
	
	public void createDataBase(String baseName)
	{
		String reqSql="create database " + baseName;
		execSQL_Update(reqSql);
	}
	
	public void dropDataBase(String baseName)
	{
		String reqSql="drop database " + baseName;
		execSQL_Update(reqSql);
	}
	
	public void createTable(String tableName, String[] paramNames, String[] paramTypes)
	{
		String cmdSQL = "create table " + tableName + "( ";
		int paramNb = paramNames.length;
		for(int i=0; i<paramNb; i++)
		{
			cmdSQL = cmdSQL + paramNames[i] + " " + paramTypes[i] +
				( (i == paramNb-1) ? " " : ", " );
		}
		cmdSQL = cmdSQL + ")";
		execSQL_Update(cmdSQL);
	}
	
	public void dropTable(String tableName)
	{
		String cmdSQL = "drop table " + tableName;
		execSQL_Update(cmdSQL);
	}
	
	public void insertIntoTable(String tableName, String[] paramNames, String[] paramValues)
	{
		String cmdSQL = "insert into " + tableName + "( ";
		int paramNb = paramNames.length; int i;
		for(i=0; i<paramNb; i++)
		{
			cmdSQL = cmdSQL + paramNames[i] + ( (i == paramNb-1) ? " " : ", " );
		}
		cmdSQL = cmdSQL + ") values ( ";
		for(i=0; i<paramNb; i++)
		{
			cmdSQL = cmdSQL + paramValues[i] + ( (i == paramNb-1) ? " " : ", " );
		}
		cmdSQL = cmdSQL + ")";
		execSQL_Update(cmdSQL); 
	}
	
	public void deleteFromTable(String tableName, String[] paramNames, String[] paramValues)
	{
		int paramNb = paramNames.length; String cmdSQL;
		cmdSQL = "delete from " + tableName;
		if( paramNb!=0 )
		{
			cmdSQL = cmdSQL + " where ";
			for(int i=0; i<paramNb; i++)
			{
				cmdSQL = cmdSQL + paramNames[i] + "=" + paramValues[i] +  
					( (i == paramNb-1) ? "" : " AND " );
			}
		}
		execSQL_Update(cmdSQL); 
	}
	
	public void updateTable(String tableName, String[] attNames, String[] neValues, 
											  String[] paramNames, String[] paramValues)
	{
		String cmdSQL = "update " + tableName + " set ";
		int paramNb; int i;
		paramNb = attNames.length; 
		for(i=0; i<paramNb; i++)
		{
			cmdSQL = cmdSQL + attNames[i] + "=" + neValues[i] +  
				( (i == paramNb-1) ? "" : " , " );
		}
		paramNb = paramNames.length;
		if(paramNb!=0)
		{
			cmdSQL = cmdSQL + " where ";
			for(i=0; i<paramNb; i++)
			{
				cmdSQL = cmdSQL + paramNames[i] + "=" + paramValues[i] + 
					( (i == paramNb-1) ? "" : " AND " );
			}
		}
		execSQL_Update(cmdSQL); 
	}
	
	public ResultSet selectFromTable(String tableName, String[] attNames, 
									 String[] paramNames, String[] paramValues)
	{
		int paramNb; int i;
		String cmdSQL = "select "; 
		paramNb = attNames.length;
		if(paramNb==0) cmdSQL = cmdSQL + "*"; 
		else
		{
			for(i=0; i<paramNb; i++)
			{
				cmdSQL = cmdSQL + attNames[i] + ( (i == paramNb-1) ? "" : ", " );
			}
		}
		cmdSQL = cmdSQL + " from " + tableName;   
		paramNb = paramNames.length;
		if(paramNb!=0)
		{
			cmdSQL = cmdSQL + " where ";
			for(i=0; i<paramNb; i++)
			{
				cmdSQL = cmdSQL + paramNames[i] + "=" + paramValues[i] +  
					( (i == paramNb-1) ? "" : " AND " );
			}
		}
		return execSQL_Query(cmdSQL); 
	}
	
	public void execSQL_Update(String reqSql)
	{
		String methode = "execSQL_Update";
		try
		{
			Statement st = connection.createStatement();
			st.executeUpdate(reqSql);
			st.close();
			System.out.println(EXE + methode + " -> " + reqSql );
		}
		catch(SQLException e)
		{
			System.out.println(ERR + " " + reqSql);
			System.out.println(ERR + methode + " -> " + e.getMessage() );
		}
	}
	
	public ResultSet execSQL_Query(String reqSql)
	{
		String methode = "execSQL_Query";
		ResultSet rs = null;
		Statement st;
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(reqSql);
			//st.close();
			//System.out.println(EXE + methode + " -> " + reqSql );
		}
		catch(SQLException e)
		{
			System.out.println(ERR + " " + reqSql);
			System.out.println(ERR + methode + " -> " + e.getMessage() );
		}
		return rs;
	}
	
	private void defineOutParamType(CallableStatement cs, int numParam, int typeParam) throws SQLException 
	{
		switch(typeParam)
		{
			case 1 : cs.registerOutParameter (numParam, Types.INTEGER); break;			
			case 2 : cs.registerOutParameter (numParam, Types.VARCHAR); break;
			case 3 : cs.registerOutParameter (numParam, Types.CHAR); break;
			case 4 : cs.registerOutParameter (numParam, Types.DATE); break;
		}
	}
	
	public void callProcedure(String procedureName, String[] paramValues, int[] paramTypes, int[] paramSort)
	{
		String methode = "callProcedure";
		int nbParams = paramValues.length; int i;
		String cmdProc = "begin " + procedureName;
		if(nbParams>0)
		{
			cmdProc = cmdProc + " (";
			//construction de la commande
			for(i=0; i<nbParams;i++)
				cmdProc = cmdProc + "?"+ ( (i == nbParams-1) ? ")" : "," );
		}		
		cmdProc = cmdProc + "; end;";
		try
		{
			CallableStatement proc = this.connection.prepareCall (cmdProc);
      		//d�finition des types des param�tres
			if(nbParams>0)
			{
				//construction de la commande
				for(i=0; i<nbParams;i++)
				{
					switch(paramSort[i])
					{
						case 0 : proc.setString(i+1,paramValues[i]); break;
						case 1 : defineOutParamType(proc, i+1, paramTypes[i]); break;			
						case 2 : proc.setString(i+1,paramValues[i]); 
								 defineOutParamType(proc, i+1, paramTypes[i]); break;
					}
				}
			}		
			proc.execute ();
      		proc.close();
			System.out.println(EXE + methode + " -> " + cmdProc );
		}
		catch(SQLException e)
		{
			System.out.println(ERR + " " + cmdProc);
			System.out.println(ERR + methode + " -> " + e.getMessage() );
		}
	}
	
	public Object callFunction(String functionName, String[] paramValues, int[] paramTypes, int[] paramSort, int returnType)
	{
		String methode = "callFunction"; Object returnObj = new Object();
		int nbParams = paramValues.length; int i;
		String cmdFunc = "begin ? := " + functionName;
		if(nbParams>0)
		{
			cmdFunc = cmdFunc + " (";
			//construction de la commande
			for(i=0; i<nbParams;i++)
				cmdFunc = cmdFunc + "?"+ ( (i == nbParams-1) ? ")" : "," );
		}		
		cmdFunc = cmdFunc + "; end;";
		try
		{
			CallableStatement func = this.connection.prepareCall (cmdFunc);
      		//d�finition des types des param�tres
			if(nbParams>0)
			{
				//construction de la commande
				for(i=0; i<nbParams;i++)
				{
					switch(paramSort[i])
					{
						case 0 : func.setString(i+2,paramValues[i]); break;
						case 1 : defineOutParamType(func, i+2, paramTypes[i]); break;			
						case 2 : func.setString(i+2,paramValues[i]); 
								 defineOutParamType(func, i+2, paramTypes[i]);
								 break;
					}
				}
			}
			//d�finition du type de retour de la fonction
			defineOutParamType(func,1,returnType);		
			func.execute ();
      		returnObj = func.getObject(1);
			func.close();
			System.out.println(EXE + methode + " -> " + cmdFunc );
		}
		catch(SQLException e)
		{
			System.out.println(ERR + " " + cmdFunc);
			System.out.println(ERR + methode + " -> " + e.getMessage() );
		}
		return returnObj;
	}
	
	public Object getValue(ResultSet rs, int i) throws SQLException
	{
		Object val = rs.getObject(i);
		if(rs.wasNull()) 
			return null;
		else
			return val;
	}
	
	public List TablesName()
	{
		String methode = "TablesName";
		List<String> tables = new ArrayList<String>();
		try
		{
			DatabaseMetaData dbmd = connection.getMetaData();
			ResultSet rs = dbmd.getTables(null, null, null, null);
			while( rs.next() )
				tables.add( rs.getString("TABLE_NAME") );
			System.out.println(EXE + methode);
		}
		catch(Exception e)
		{
			System.out.println(ERR + methode + " -> " + e.getMessage() );
		}
		return tables;
	}
}	
	 
