package org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.dbinfodiscoverer.dbutils.DBconnect;
import org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders.RelationalDBContentModelBuilder;

/**
 * Database content information retrieval dedicated class
 * @author Hugo Bruneliere
 */
public class RelationalDBContentInfoRetriever extends InfoRetriever {
	
	private DBconnect conn;
	
	/**
	 * @param conn
	 */
	public RelationalDBContentInfoRetriever(DBconnect conn, ModelHandler mh, ReferenceModel metametamodel, 
											Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> loadMetamodelParams) {
		super(new RelationalDBContentModelBuilder(mh, metametamodel, metamodelInjector, loadMetamodelParams));
		this.conn = conn;
	}

	public void discover(Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams) {
		((RelationalDBContentModelBuilder) getModelBuilder()).newModel(conn.getBaseName()+"_DBContent",conn.getBaseName());
		ResultSet tablesList = conn.execSQL_Query("show tables");
		try {
			while(tablesList.next()) {
				String tableName = tablesList.getString(1);
				((RelationalDBContentModelBuilder) getModelBuilder()).newTable(tableName);
				
				ResultSet tableColumnsList = conn.execSQL_Query("show columns from "+tableName);
				tableColumnsList.last();
				int numColumns = tableColumnsList.getRow();
				tableColumnsList.close();
	
				ResultSet tableTuplesList = conn.execSQL_Query("select * from "+tableName);
				while(tableTuplesList.next()) {
					List<String> tupleValues = new ArrayList<String>(10);
					for(int index = 1; index <= numColumns; index++) {
						tupleValues.add(tableTuplesList.getString(index));
					}
					((RelationalDBContentModelBuilder) getModelBuilder()).newTuple(tupleValues);
				}
				tableTuplesList.close();
			}
			tablesList.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		((RelationalDBContentModelBuilder) getModelBuilder()).save(modelExtractor, saveModelParams);
	}
	
}
