package org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders;

import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;

public abstract class SchemaModelBuilder extends ModelBuilder {

	public SchemaModelBuilder(ModelHandler mh, ReferenceModel metametamodel, Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> params) {
		super(mh, metametamodel, metamodelInjector, params);
	}

	public abstract void newModel(String modelName, String databaseName);
	
	public abstract void newTable(String tableName);
	
	public abstract void newColumn(String fieldName, String type, boolean isNull, boolean isKey, String defaultValue);
	
}
