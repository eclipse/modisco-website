/*
 * Copyright (c) 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;

/**
 * Database content model building dedicated class
 * @author Hugo Bruneliere
 */
public class RelationalDBContentModelBuilder extends ModelBuilder{
	
	private ModelElement currentTable;
	private ModelElement currentDatabase;

	/**
	 * 
	 */
	public RelationalDBContentModelBuilder(ModelHandler mh, ReferenceModel metametamodel,  Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> params) {
		super(mh, metametamodel, metamodelInjector, params);
		this.currentDatabase = null;
		this.currentTable = null;
	}
	
	public void newModel(String modelName, String databaseName) {
		initNewModel(modelName);
		ModelElement newDatabase;
		newDatabase = getCurrentModel().createModelElement(getMetamodel().getReferenceModelElementByName("RelationalDBContent::DataBase"));
		newDatabase.set("name", databaseName);
		newDatabase.set("SGBDname", "MySQL");
		this.currentDatabase = newDatabase;
	}
	
	public void newTable(String tableName) {
		if(getCurrentModel()!=null) {
			ModelElement newTable;
			newTable = getCurrentModel().createModelElement(getMetamodel().getReferenceModelElementByName("RelationalDBContent::Table"));
			newTable.set("name", tableName);
			this.currentDatabase.add("tables", newTable);
			this.currentTable = newTable;
		}
	}
	
	public void newTuple(List<String> tupleValues) {
		if(getCurrentModel()!=null && currentTable!=null) {
			ModelElement newTuple;
			newTuple = getCurrentModel().createModelElement(getMetamodel().getReferenceModelElementByName("RelationalDBContent::Tuple"));
			for(Iterator it = tupleValues.iterator(); it.hasNext(); ) {
				String value = (String) it.next();
				ModelElement newTupleElement = getCurrentModel().createModelElement(getMetamodel().getReferenceModelElementByName("RelationalDBContent::TupleElement"));
				newTupleElement.set("value", value);
				newTuple.add("elements", newTupleElement);
			}
			this.currentTable.add("tuples", newTuple);
		}
	}
	
}
