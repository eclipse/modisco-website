package org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders;

import java.util.List;
import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;

public class KDMSchemaModelBuilder extends SchemaModelBuilder {

	private ModelElement currentRelationalSchema=null;
	private ModelElement currentRelationalTable=null;
	private ModelElement SqlDataTypes=null;
	
	
	public KDMSchemaModelBuilder(ModelHandler mh, ReferenceModel metametamodel, Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> params) {
		super(mh, metametamodel, metamodelInjector, params);	
	}

	public void newModel(String modelName, String databaseName) {
		initNewModel(modelName);
		
		ModelElement mainSegment;
		mainSegment = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::kdm::Segment"));
		mainSegment.set("name", modelName);
		
		ModelElement dataModel;
		dataModel = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::data::DataModel"));
		dataModel.set("name", databaseName);
		mainSegment.add("model",dataModel);
		
		ModelElement codeModel;
		codeModel = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::CodeModel"));
		mainSegment.add("model",codeModel);
		ModelElement languageUnit;
		languageUnit = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::LanguageUnit"));
		languageUnit.set("name", "SQL datatypes");
		codeModel.add("codeElement", languageUnit);
		ModelElement integerType;
		integerType = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::IntegerType"));
		integerType.set("name", "SQL int");
		languageUnit.add("codeElement", integerType);
		ModelElement stringType;
		stringType = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::StringType"));
		stringType.set("name", "SQL varchar");
		languageUnit.add("codeElement", stringType);
		ModelElement decimalType;
		decimalType = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::DecimalType"));
		decimalType.set("name", "SQL decimal");
		languageUnit.add("codeElement", decimalType);
		ModelElement dateType;
		dateType = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::DateType"));
		dateType.set("name", "SQL date");
		languageUnit.add("codeElement", dateType);
		this.SqlDataTypes=languageUnit;
				
		ModelElement relationalSchema;
		relationalSchema = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::data::RelationalSchema"));
		relationalSchema.set("name", databaseName);
		dataModel.add("dataElement", relationalSchema);
		this.currentRelationalSchema = relationalSchema;
	}
	
	public void newTable(String tableName) {
		if(this.getCurrentModel()!=null && this.currentRelationalSchema!=null) {	
			ModelElement relationalTable;
			relationalTable = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::data::RelationalTable"));
			relationalTable.set("name", tableName);
			this.currentRelationalSchema.add("codeElement", relationalTable);
			this.currentRelationalTable = relationalTable;
		}
	}
	
	private ModelElement getSqlDataType(String databaseDataType) {
		ModelElement sqlDataType;
		if( databaseDataType.contains("int") )
			sqlDataType= (ModelElement) ( (List) this.SqlDataTypes.get("codeElement") ).get(0);
		else
			if( databaseDataType.contains("double") )
				sqlDataType= (ModelElement) ( (List) this.SqlDataTypes.get("codeElement") ).get(2);
			else
				if( databaseDataType.contains("datetime") )
					sqlDataType= (ModelElement) ( (List) this.SqlDataTypes.get("codeElement") ).get(3);
				else
					sqlDataType= (ModelElement) ( (List) this.SqlDataTypes.get("codeElement") ).get(1);
		return sqlDataType;
	}
	
	private ModelElement getCurrentKey() {
		ModelElement key=null;
		for(Object o : ( (List) this.currentRelationalTable.get("itemUnit"))) {
			ModelElement me = (ModelElement) o; 
			if( me.isTypeOf(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::data::UniqueKey"))) {
				key=me;
				break;
			}
		}
		return key;
	}
	
	public void newColumn(String fieldName, String type, boolean isNull, boolean isKey, String defaultValue) {
		if(this.getCurrentModel()!=null && this.currentRelationalTable!=null) {
			ModelElement item;
			item = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::code::ItemUnit"));
			item.set("name", fieldName);
			item.set("type", this.getSqlDataType(type));
			if( isKey )
			{
				ModelElement uniqueKey = this.getCurrentKey();
				if( uniqueKey==null ) {
					uniqueKey = this.getCurrentModel().createModelElement(this.getMetamodel().getReferenceModelElementByName("KDM_MetaModel::data::UniqueKey"));
					this.currentRelationalTable.add("itemUnit", uniqueKey);
				}
				uniqueKey.add("implementation", item);
			}
			this.currentRelationalTable.add("itemUnit", item);
		}
	}
	
}
