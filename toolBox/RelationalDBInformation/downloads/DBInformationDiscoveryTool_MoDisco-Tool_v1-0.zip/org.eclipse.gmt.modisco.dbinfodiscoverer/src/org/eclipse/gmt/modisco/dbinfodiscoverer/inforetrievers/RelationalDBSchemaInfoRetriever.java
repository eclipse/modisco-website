/*
 * Copyright (c) 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.dbinfodiscoverer.dbutils.DBconnect;
import org.eclipse.gmt.modisco.dbinfodiscoverer.modelbuilders.RelationalDBSchemaModelBuilder;

/**
 * Database schema information retrieval dedicated class
 * @author Hugo Bruneliere
 */
public class RelationalDBSchemaInfoRetriever extends InfoRetriever {

	private DBconnect conn;

	/**
	 * @param conn
	 */
	public RelationalDBSchemaInfoRetriever(	DBconnect conn, ModelHandler mh, ReferenceModel metametamodel, 
											Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> loadMetamodelParams) {
		super(new RelationalDBSchemaModelBuilder(mh, metametamodel, metamodelInjector, loadMetamodelParams));
		this.conn = conn;
	}
	
	public void discover(Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams) {
		((RelationalDBSchemaModelBuilder) getModelBuilder()).newModel(conn.getBaseName()+"_DBSchema",conn.getBaseName());
		ResultSet tablesList = conn.execSQL_Query("show tables");
		try {
			while(tablesList.next()) {
				String tableName = tablesList.getString(1);
				((RelationalDBSchemaModelBuilder) getModelBuilder()).newTable(tableName);
				/*
				 * It is also possible to use the command 'describe tableName'...
				 */
				ResultSet tableColumnsList = conn.execSQL_Query("show columns from "+tableName);
				while(tableColumnsList.next()) {
					String fieldName = tableColumnsList.getString("Field");
					String type = tableColumnsList.getString("Type");
					boolean isNull = tableColumnsList.getBoolean("Null");
					boolean isKey = false;
					if( tableColumnsList.getString("Key").equals("PRI") )
						isKey = true;
					String defaultValue = tableColumnsList.getString("Default");
					((RelationalDBSchemaModelBuilder) getModelBuilder()).newColumn(fieldName,type,isNull,isKey,defaultValue);
				}
				tableColumnsList.close();
			}
			tablesList.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		((RelationalDBSchemaModelBuilder) getModelBuilder()).save(modelExtractor, saveModelParams);
	}
	
}
