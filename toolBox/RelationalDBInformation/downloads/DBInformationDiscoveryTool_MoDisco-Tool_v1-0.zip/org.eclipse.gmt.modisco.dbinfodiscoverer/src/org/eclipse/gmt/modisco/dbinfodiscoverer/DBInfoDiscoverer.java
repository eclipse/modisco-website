/*
 * Copyright (c) 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.dbinfodiscoverer;

import java.util.Map;

import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.dbinfodiscoverer.dbutils.DBconnect;
import org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers.InfoRetriever;
import org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers.RelationalDBContentInfoRetriever;
import org.eclipse.gmt.modisco.dbinfodiscoverer.inforetrievers.RelationalDBSchemaInfoRetriever;

/**
 * MoDisco tool for discovering (as models) schema & content information on databases
 * @author Hugo Bruneliere
 */
public class DBInfoDiscoverer {
	
	private DBconnect dbcon;
	private InfoRetriever dbInfoRetriever;
	
	/*
	 * Metamodels supported by the discoverer
	 */
	public static final int RelationalDBSchema_M2 = 1;
	public static final int KDM_M2 = 2; 
	
	
	/**
	 * Builds a new information discoverer for the specified database server by using the given JDBC driver. 
	 * Note that the JDBC driver's Jar must be included in the build path of the program that calls this discoverer.  
	 * @param JDBCdriverName
	 * @param databaseServerUrl
	 */
	public DBInfoDiscoverer(String JDBCdriverName, String databaseServerUrl) {
		this.dbcon = new DBconnect(JDBCdriverName,databaseServerUrl);
		this.dbcon.loadDriver();
		this.dbInfoRetriever = null;
	}
	
	private void launchDiscovery(	String databaseName, String userName, String userPassword,
									Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams) {
		this.dbcon.connectTo(databaseName, userName, userPassword);
		System.out.println("\n**************************************\n");
		this.dbInfoRetriever.discover(modelExtractor, saveModelParams);
		System.out.println("\n**************************************\n");
		this.dbcon.disconnect();
	}
	
	/**
	 * Launches the database schema discovery process on the specified database using the given properties.
	 * @param databaseName
	 * @param userName
	 * @param userPassword
	 * @param modelHandler
	 * @param metametamodel
	 * @param metamodelInjector
	 * @param loadMetamodelParams
	 * @param modelExtractor
	 * @param saveModelParams
	 * @param metamodel
	 */
	public void launchSchemaDiscovery( 	String databaseName, String userName, String userPassword,
										ModelHandler modelHandler, ReferenceModel metametamodel, 
										Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> loadMetamodelParams,
										Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams,
										int metamodel) {
		if(	metamodel==DBInfoDiscoverer.RelationalDBSchema_M2
			|| metamodel==DBInfoDiscoverer.KDM_M2) {
			this.dbInfoRetriever = new RelationalDBSchemaInfoRetriever(this.dbcon, modelHandler, metametamodel, metamodelInjector, loadMetamodelParams, metamodel);
			this.launchDiscovery(databaseName, userName, userPassword, modelExtractor, saveModelParams);
		}
		else {
			System.out.println("-> Discovery aborted: the metamodel specified cannot be used for database schema discovery!!!");
		}
	}
	
	/**
	 * Launches the database content discovery process on the specified database using the given properties.
	 * @param databaseName
	 * @param userName
	 * @param userPassword
	 * @param modelHandler
	 * @param metametamodel
	 * @param metamodelInjector
	 * @param loadMetamodelParams
	 * @param modelExtractor
	 * @param saveModelParams
	 */
	public void launchContentDiscovery( 	String databaseName, String userName, String userPassword,
											ModelHandler modelHandler, ReferenceModel metametamodel, 
											Injector metamodelInjector, Map<String, ProjectorActualParameter<?>> loadMetamodelParams,
											Extractor modelExtractor, Map<String, ProjectorActualParameter<?>> saveModelParams) {
		this.dbInfoRetriever = new RelationalDBContentInfoRetriever(this.dbcon, modelHandler, metametamodel, metamodelInjector, loadMetamodelParams);
		this.launchDiscovery(databaseName, userName, userPassword, modelExtractor, saveModelParams);
	}
	
}
