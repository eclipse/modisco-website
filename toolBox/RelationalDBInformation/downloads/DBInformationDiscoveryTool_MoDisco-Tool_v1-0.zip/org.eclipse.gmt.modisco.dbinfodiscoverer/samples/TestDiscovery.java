package ???;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.gmt.modisco.dbinfodiscoverer.DBInfoDiscoverer;
import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modelhandler.ModelHandlerManager;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.modelhandler.emf.EMFModelHandler;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFReferenceModel;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFExtractor;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFInjector;


/**
 * Test programm for launching the database information discoverers
 * @author Hugo Bruneliere
 */
public class TestDiscovery {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String JDBCdriverName = "com.mysql.jdbc.Driver";
		String metamodelPath = "src/org/eclipse/gmt/modisco/dbinfodiscoverer/resources/";
		
		String databaseServerUrl = "jdbc:mysql://localhost";
		String databaseName = "classicmodels";
		String userName = "myName";
		String password = "";
		String modelPath = "samples/";
		
		ModelHandlerManager mhm = ModelHandlerManager.getInstance(); 
		
		ModelHandler emfmh = new EMFModelHandler(); 
		mhm.putModelHandler("EMF", emfmh);
		
		ReferenceModel metametamodel = EMFReferenceModel.getMetametamodel();
		
		DBInfoDiscoverer discoverer = new DBInfoDiscoverer(JDBCdriverName, databaseServerUrl);
		
		/*
		 * Discover database schema
		 */
		Injector emfinj = EMFInjector.getInstance();
		Map<String, ProjectorActualParameter<?>> metamodelParams = new HashMap<String, ProjectorActualParameter<?>>();
		metamodelParams.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI(metamodelPath+"RelationalDBSchema.ecore")));
			
		Extractor emfext = EMFExtractor.getInstance();
		Map<String, ProjectorActualParameter<?>> modelParams = new HashMap<String, ProjectorActualParameter<?>>();
		modelParams.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI(modelPath+"BIRTSampleDB-schema.ecore")));	
		
		discoverer.launchSchemaDiscovery(	databaseName, userName, password, 
											emfmh, metametamodel, 
											emfinj, metamodelParams, 
											emfext, modelParams);
		
		/*
		 * Discover database content
		 */
		metamodelParams.clear();
		metamodelParams.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI(metamodelPath+"RelationalDBContent.ecore")));
			
		modelParams.clear();
		modelParams.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI(modelPath+"BIRTSampleDB-content.ecore")));	
		
		discoverer.launchContentDiscovery(	databaseName, userName, password, 
											emfmh, metametamodel, 
											emfinj, metamodelParams, 
											emfext, modelParams);
		
	}

}
