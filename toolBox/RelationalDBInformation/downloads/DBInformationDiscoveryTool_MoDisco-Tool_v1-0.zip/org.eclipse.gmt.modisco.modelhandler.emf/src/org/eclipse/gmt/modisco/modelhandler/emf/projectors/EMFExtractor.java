/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Hugo Bruneliere
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.projectors;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.ExtractorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.core.projectors.ProjectorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorFormalParameter;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFModel;

/**
 * Class implementing an EMF standard extractor
 */
public class EMFExtractor extends Extractor {

	private static EMFExtractor INSTANCE;
	
	private EMFExtractor() {
		this.getFormalParameters().put("URI", 
			new ProjectorFormalParameter<URI>(URI.class) {
				@Override
				public boolean checkConstraint(Object o) throws IllegalArgumentException {
					URI value = this.checkType(o);
					return (value != null);
			}});
	}
	
	public static EMFExtractor getInstance() {
		if (EMFExtractor.INSTANCE == null) {
			EMFExtractor.INSTANCE = new EMFExtractor();
		}
		return EMFExtractor.INSTANCE;
	}
	
	@Override
	public void extract(Model source, Map<String, ProjectorActualParameter<?>> parameters) throws ExtractorException {
		try {
			this.checkParameters(parameters);
		} catch (ProjectorException e) {
			throw new ExtractorException(e.getMessage());
		}
		try {
			if( ((EMFModel)source).getResource().getURI() == null )
				((EMFModel)source).getResource().setURI((URI)parameters.get("URI").getValue());
			Map<String, String> options = new HashMap<String, String>();
			options.put(XMIResource.OPTION_ENCODING, "ISO-8859-1");
			((EMFModel)source).getResource().save(new FileOutputStream(((URI)parameters.get("URI").getValue()).toFileString()), options);
		} catch (FileNotFoundException e) {
			throw new ExtractorException(e);
		} catch (IOException e) {
			throw new ExtractorException(e);
		}
	}

}
