/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.modeling;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmt.modisco.core.modeling.Feature;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModelElement;
import org.eclipse.gmt.modisco.core.modeling.SimpleFeature;

public class EMFReferenceModelElement extends EMFModelElement implements ReferenceModelElement {

	public EMFReferenceModelElement(EMFModel model, EMFReferenceModelElement referenceModelElement, EObject eObject) {
		super(model, referenceModelElement, eObject);
	}

	protected EMFReferenceModelElement(EMFModel model, EObject eObject) {
		super(model, eObject);
	}
	
	public Feature getFeature(String name) {
		EClass eClass = (EClass)this.getEObject();
		EStructuralFeature eSF = eClass.getEStructuralFeature(name);
		return this.toFeature(eSF);
	}

	public Collection<? extends Feature> getFeatures() {
		Collection<Feature> ret = new ArrayList<Feature>(); 
		EClass eClass = (EClass)this.getEObject();
		for (Object eSF : eClass.getEAllStructuralFeatures()) {
			if (!((EStructuralFeature)eSF).isTransient())
				ret.add(this.toFeature((EStructuralFeature)eSF));
		}
		return ret;
	}

	public String getName() {
		return (String)this.get("name");
	}

	public boolean isA(ReferenceModelElement other) {
		boolean ret = this == other;
		
		if(!ret) {
			for(Iterator i = ((Collection)get("eSuperTypes")).iterator() ; i.hasNext() && !ret ; ) {
				ReferenceModelElement sup = (ReferenceModelElement)i.next();
				ret = sup.isA(other);
			}
		}
		
		return ret;
	}
	
	private Feature toFeature(EStructuralFeature eSF) {
		boolean isContainer = false;
		boolean isPrimitive = false;
		EClassifier type = eSF.getEType();
		
		if (eSF instanceof EReference) {
			isContainer = ((EReference)eSF).isContainment();
		}
		
		if (eSF instanceof EAttribute) {
			isPrimitive = ( ((EAttribute)eSF).getEType() instanceof EDataType );
		}
		
		Feature ret = new SimpleFeature(
			this,
			eSF.getName(),
			eSF.isMany(),
			isContainer,
			isPrimitive,
			((EMFModel)this.getModel()).getEMFModelElementFromEObject(type));
		return ret;
	}
}
