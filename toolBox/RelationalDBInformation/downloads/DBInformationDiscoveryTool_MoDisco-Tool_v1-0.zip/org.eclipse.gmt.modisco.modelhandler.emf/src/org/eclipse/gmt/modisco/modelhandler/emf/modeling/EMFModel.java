/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.modeling;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModelElement;

public class EMFModel implements Model {

	private EMFReferenceModel referenceModel;
	private Resource resource;
	
	protected Map<EObject, EMFModelElement> eObjectToModelElement;
	
	protected EMFModel() {
		this(null);
	}
	
	protected EMFModel(EMFReferenceModel referenceModel) {
		this(referenceModel, null);
	}
	
	public EMFModel(EMFReferenceModel referenceModel, Resource resource) {
		this.eObjectToModelElement = new HashMap<EObject, EMFModelElement>();
		this.referenceModel = referenceModel;
		this.resource = resource;
	}
	
	public Collection<? extends EMFModelElement> getContents() {
		Collection<EMFModelElement> ret = new ArrayList<EMFModelElement>();
		
		for(Object current : this.resource.getContents()) {
			ret.add(this.getEMFModelElementFromEObject((EObject)current));
		}
		
		return ret;
	}

	public Set<? extends EMFModelElement> getModelElementsByKind(ReferenceModelElement referenceModelElement) {
		Set<EMFModelElement> ret = new HashSet<EMFModelElement>();
		
		TreeIterator ti = this.resource.getAllContents();
		while(ti.hasNext()) {
			EMFModelElement current = this.getEMFModelElementFromEObject((EObject)ti.next());
			if(current.isKindOf(referenceModelElement)) {
				ret.add(current);
			}
		}
		
		return ret;
	}

	public Set<? extends EMFModelElement> getModelElementsByType(ReferenceModelElement referenceModelElement) {
		Set<EMFModelElement> ret = new HashSet<EMFModelElement>();
		
		TreeIterator ti = this.resource.getAllContents();
		while(ti.hasNext()) {
			EMFModelElement current = this.getEMFModelElementFromEObject((EObject)ti.next());
			if(current.isTypeOf(referenceModelElement)) {
				ret.add(current);
			}
		}
		
		return ret;
	}

	public EMFReferenceModel getReferenceModel() {
		return this.referenceModel;
	}

	public EMFModelElement createModelElement(ReferenceModelElement referenceModelElement) {
		EMFModelElement me = null;
		EObject eObject = ((EClass)((EMFReferenceModelElement)referenceModelElement).getEObject()).getEPackage().getEFactoryInstance().create((EClass)((EMFReferenceModelElement)referenceModelElement).getEObject());
		me = new EMFModelElement(this, (EMFReferenceModelElement)referenceModelElement, eObject);
		
		eObjectToModelElement.put(eObject, me);
		this.resource.getContents().add(eObject);
		return me;
	}

	// TODO: put in protected visibility
	public Resource getResource() {
		return resource;
	}
	
//	 TODO: put in protected visibility
	public void setResource(Resource resource) {
		this.resource = resource;
	}
	
	// Should only be used to create the metametamodel
	protected void setReferenceModel(EMFReferenceModel referenceModel) {
		this.referenceModel = referenceModel;
	}

	protected EMFModelElement getEMFModelElementFromEObject(EObject eObject) {
		EMFModelElement ret = eObjectToModelElement.get(eObject);
		if (ret == null) {
			EMFReferenceModelElement referenceModelElement = 
				(EMFReferenceModelElement)this.referenceModel.eObjectToModelElement.get(eObject.eClass());
			if (referenceModelElement == null) {
				if (this.equals(EMFReferenceModel.getMetametamodel())) {
					referenceModelElement = new EMFReferenceModelElement(this, null, eObject.eClass());
					referenceModelElement.setEMFReferenceModelElement(referenceModelElement);
					this.eObjectToModelElement.put(eObject.eClass(), referenceModelElement);
				} else {
					referenceModelElement = (EMFReferenceModelElement)this.referenceModel.getEMFModelElementFromEObject(eObject.eClass());
					this.referenceModel.eObjectToModelElement.put(eObject.eClass(), referenceModelElement);
				}
			}
			
			if (this instanceof EMFReferenceModel) {
				ret = new EMFReferenceModelElement(this, referenceModelElement, eObject);
			} else {
				ret = new EMFModelElement(this, referenceModelElement, eObject);
			}
			eObjectToModelElement.put(eObject, ret);
		}
		if (ret == null) {
			System.err.println("There is a bug getEMFModelElementFromEObject()");
		} 
		else if (ret.getEObject() != eObject) {
			System.err.println("There is a bug here");
			throw new RuntimeException("getEMFModelElementFromEObject() post condition not satisfied");
		}
		return ret;
	}
}
