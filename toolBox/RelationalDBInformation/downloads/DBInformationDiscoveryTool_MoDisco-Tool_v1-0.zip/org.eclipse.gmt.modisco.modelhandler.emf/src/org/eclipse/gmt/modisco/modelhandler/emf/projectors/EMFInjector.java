/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.projectors;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.InjectorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.core.projectors.ProjectorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorFormalParameter;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFModel;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFModelElement;

public class EMFInjector extends Injector {

	private static EMFInjector INSTANCE;
	
	private EMFInjector() {
		this.getFormalParameters().put("URI", 
			new ProjectorFormalParameter<URI>(URI.class) {
				@Override
				public boolean checkConstraint(Object o) throws IllegalArgumentException {
					URI value = this.checkType(o);
					return (value != null);
			}});
	}
	
	public static EMFInjector getInstance() {
		if (EMFInjector.INSTANCE == null) {
			EMFInjector.INSTANCE = new EMFInjector();
		}
		return EMFInjector.INSTANCE;
	}
	
	@Override
	public EMFModelElement inject(Model target, Map<String, ProjectorActualParameter<?>> parameters) throws InjectorException {
		try {
			this.checkParameters(parameters);
		} catch (ProjectorException e) {
			throw new InjectorException(e.getMessage());
		}
		try {
			Resource resource = ((EMFModel)target).getResource().getResourceSet().createResource(((URI)parameters.get("URI").getValue()));
			((EMFModel)target).setResource(resource);
			((EMFModel)target).getResource().load(new FileInputStream(((URI)parameters.get("URI").getValue()).toFileString()), Collections.EMPTY_MAP);
			((EMFModel)target).setResource(resource);
		} catch (FileNotFoundException e) {
			throw new InjectorException(e);
		} catch (IOException e) {
			throw new InjectorException(e);
		}
		return (EMFModelElement)target.getContents().toArray()[0];
	}
}
