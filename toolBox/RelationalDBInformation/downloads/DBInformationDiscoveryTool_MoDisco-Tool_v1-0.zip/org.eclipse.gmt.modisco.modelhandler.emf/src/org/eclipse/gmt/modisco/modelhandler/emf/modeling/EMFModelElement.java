/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.modeling;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmt.modisco.core.modeling.EnumLiteral;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModelElement;
import org.eclipse.gmt.modisco.modelhandler.emf.EMFModelHandlerException;

public class EMFModelElement implements ModelElement {

	private EMFModel model;
	private EMFReferenceModelElement referenceModelElement;
	private EObject eObject;
	
	public EMFModelElement(EMFModel model, EMFReferenceModelElement referenceModelElement, EObject eObject) {
		this.model = model;
		this.referenceModelElement = referenceModelElement;
		this.eObject = eObject;
	}
	
	protected EMFModelElement(EMFModel model, EObject eObject) {
		this.model = model;
		this.eObject = eObject;
	}
	
	public Object get(String propertyName) {
		Object value = null;
		EStructuralFeature feature = this.getEStructuralFeature(propertyName);
		if (feature.getEType() instanceof EEnum){
			value = new EnumLiteral(((EEnumLiteral)this.eObject.eGet(feature)).getLiteral());
		} else {
			value = this.eObject.eGet(feature);
		}
		
		if (value != null && value instanceof List) {
			List<Object> list = new ArrayList<Object>();
			for (Object e: (List)value) {
				if (e instanceof EObject)
					list.add(this.model.getEMFModelElementFromEObject((EObject)e));
				else
					list.add(e);
			}
			return list;
		} else if (value != null && value instanceof EObject) {
			return this.model.getEMFModelElementFromEObject((EObject)value);
		} else {
			return value;
		}
	}
	
	public void add(String propertyName, Object value) {
		EStructuralFeature feature = this.getEStructuralFeature(propertyName);			
		if (feature.isMany()) {
			Object list = this.eObject.eGet(feature);
			if (list != null && list instanceof List){
				if (value != null){
					if (value instanceof ModelElement) {
						if (value instanceof EMFModelElement) {
							((List)list).add(((EMFModelElement)value).eObject);
							if (this.model.getResource().getContents().contains(((EMFModelElement)value).eObject)) {
								this.model.getResource().getContents().remove(((EMFModelElement)value).eObject);
							} 
						} else {
							throw new IllegalArgumentException("given value for property " + feature.getName() + " is a model element not managed by EMFModelHandler.");
						}
					} else if (value instanceof Collection) {
						for (EMFModelElement e : ((Collection<EMFModelElement>)value)) {
							((List)list).add(e.eObject);
							if (this.model.getResource().getContents().contains(((EMFModelElement)e).eObject)) {
								this.model.getResource().getContents().remove(((EMFModelElement)e).eObject);
							} 
						}
					} else {
						((List)list).add(value);
					}
				} else {
					throw new IllegalArgumentException("Trying to add a null value to a single-valued property (" + propertyName + ").");
				}
			} else {
				throw new RuntimeException("Unexpected exception (trying to add value to unsetted list).");
			}
		} else {
			throw new IllegalArgumentException("Trying to add a value to a single-valued property (" + propertyName + ").");
		}
	}

	public void remove(String propertyName, Object value) {
		// TODO Auto-generated method stub
		
	}

	public EMFModelElement getContainer() {
		return this.model.getEMFModelElementFromEObject(this.eObject.eContainer());
	}

	public Collection<? extends EMFModelElement> getContents() {
		Collection<EMFModelElement> ret = new ArrayList<EMFModelElement>();
		
		for(Object current : this.eObject.eContents()) {
			ret.add(this.model.getEMFModelElementFromEObject((EObject)current));
		}
		
		return ret;
	}

	public EMFModel getModel() {
		return this.model;
	}

	public EMFReferenceModelElement getReferenceModelElement() {
		if (referenceModelElement == null) {
			referenceModelElement = (EMFReferenceModelElement)this.model.getEMFModelElementFromEObject(this.eObject.eClass());
		}
		return referenceModelElement;
	}

	public boolean isKindOf(ReferenceModelElement referenceModelElement) {
		return this.referenceModelElement.isA(referenceModelElement);
	}

	public boolean isTypeOf(ReferenceModelElement referenceModelElement) {
		return (this.referenceModelElement == referenceModelElement);
	}

	public void set(String propertyName, Object value) {
		EStructuralFeature feature = this.getEStructuralFeature(propertyName);			
		if (feature.isChangeable()) {
			if (feature.getEType() instanceof EEnum) {
				if (value instanceof String) {
					EEnumLiteral enumLiteral = ((EEnum)feature.getEType()).getEEnumLiteralByLiteral((String)value);
					if (enumLiteral != null) {
						this.eObject.eSet(feature, enumLiteral);
					} else {
						throw new IllegalArgumentException("given value is not a valid literal for property " + propertyName + "."); 
					}
				} else {
					throw new ClassCastException("property " + propertyName + " is an EEnum, value has to be of type String.");
				}
			} else if (!feature.isMany()) {
				this.setSingleFeature(feature, value);
			} else {
				this.setMultiFeature(feature, value);
			}
		} else {
			throw new IllegalArgumentException("property " + propertyName + " is read-only");
		}
	}
	
	public void unset(String propertyName) {
		EStructuralFeature feature = this.getEStructuralFeature(propertyName);
		if (feature.isMany()) {
			this.set(propertyName, Collections.EMPTY_LIST);
		} else {
			this.set(propertyName, null);
		}
	}

	protected void setEMFReferenceModelElement(EMFReferenceModelElement referenceModelElement) {
		this.referenceModelElement = referenceModelElement;
	}
	
	protected void setEObject(EObject eObject) {
		this.eObject = eObject;
	}
	
	protected EObject getEObject() {
		return this.eObject;
	}
		
	private EStructuralFeature getEStructuralFeature(String name) {
		EStructuralFeature structuralFeature = this.eObject.eClass().getEStructuralFeature(name);
		if (structuralFeature == null){
			throw new IllegalArgumentException("there is no feature named " + name + " in " + this.toString() + ".");
		}
		return structuralFeature;
	}
	
	private Object getFromMethodCall(String name, Object arg) throws EMFModelHandlerException {
		try{
			Method method = this.eObject.getClass().getMethod(name, (arg != null)? new Class []{arg.getClass()} : new Class []{});
			return method.invoke(this.eObject, (arg != null)? new Object []{arg} : new Object []{});
		} catch (Exception e){
			throw new EMFModelHandlerException(e.getMessage());
		}
	}
	
	private void setMultiFeature(EStructuralFeature feature, Object value) {
		BasicEList eList = new BasicEList();
		if (value instanceof ModelElement) {
			if (value instanceof EMFModelElement) {
				eList.add(((EMFModelElement)value).eObject);
			} else {
				throw new IllegalArgumentException("given value for property " + feature.getName() + " is a model element not managed by EMFModelHandler.");
			}
		} else if (value instanceof Collection) {
			boolean modelElementCollection = false;
			boolean objectCollection = false;
			for (Object e: (Collection)value) {
				if (e instanceof ModelElement) { 
					if (e instanceof EMFModelElement) {
						modelElementCollection = true;
						eList.add(((EMFModelElement)e).eObject);
						if (this.model.getResource().getContents().contains(((EMFModelElement)e).eObject)) {
							this.model.getResource().getContents().remove(((EMFModelElement)e).eObject);
						} 
					} else {
						throw new IllegalArgumentException("given value for property " + feature.getName() + " is a collection of model elements not only managed by EMFModelHandler.");
					}
				} else {
					if (!(e instanceof Collection)) {
						objectCollection = true;
						eList.add(e);
					} else {
						throw new IllegalArgumentException("trying to assign a collection of collection to the property " + feature.getName() + ".");
					}	
				}
			}
			if (modelElementCollection && objectCollection) {
				throw new IllegalArgumentException("trying to mix ModelElement and primitive types object in the multi-valued property " + feature.getName() + ".");
			}
		} else if (value != null) {
			eList.add(value);
		}
		this.eObject.eSet(feature, eList);
	}
	
	private void setSingleFeature(EStructuralFeature feature, Object value) {
		if (value instanceof ModelElement) {
			if (value instanceof EMFModelElement) {
				this.eObject.eSet(feature, ((EMFModelElement)value).eObject);
				if (this.model.getResource().getContents().contains(((EMFModelElement)value).eObject)) {
					this.model.getResource().getContents().remove(((EMFModelElement)value).eObject);
				}
			} else {
				throw new IllegalArgumentException("given value for property " + feature.getName() + " is a model element not managed by EMFModelHandler.");
			}
		} else if (!(value instanceof Collection)){
			this.eObject.eSet(feature, value);
		} else {
			throw new IllegalArgumentException("trying to set a single-valued feature to a collection type for property " + feature.getName() + ".");
		}
	}
}
