/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf;

import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.impl.EPackageRegistryImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceFactoryRegistryImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Extractor;
import org.eclipse.gmt.modisco.core.projectors.ExtractorException;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.InjectorException;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFModel;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFReferenceModel;

public class EMFModelHandler implements ModelHandler {

	public static String ECORE_FILEEXTENSION = "ecore";
	public static String CONTAINER_SEPARATOR = "::";
	
	private ResourceSet resourceSet;
	
	public EMFModelHandler() {
		this.resourceSet = new ResourceSetImpl();
		
		this.resourceSet.setResourceFactoryRegistry(new ResourceFactoryRegistryImpl());
		this.resourceSet.setPackageRegistry(new EPackageRegistryImpl());
		this.resourceSet.getResources().add(EcorePackage.eINSTANCE.eResource());
		this.resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(EMFModelHandler.ECORE_FILEEXTENSION, new EcoreResourceFactoryImpl());
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gmt.modisco.core.modelHandler.ModelHandler#closeModel(org.eclipse.gmt.modisco.core.modeling.Model)
	 */
	public void closeModel(Model model) {
		throw new UnsupportedOperationException();
	}

	public boolean isHandling(Model model) {
		return (model instanceof EMFModel);
	}

	public EMFModel createModel(ReferenceModel referenceModel) {
		if (!(referenceModel instanceof EMFReferenceModel)) {
			throw new IllegalArgumentException("reference model is not an EMFReferenceModel");
		}
		EMFModel ret = null;
		ResourceImpl resource = new XMIResourceImpl();
		resource.basicSetResourceSet(this.resourceSet, null);
		if (referenceModel.equals(EMFReferenceModel.getMetametamodel())) {
			ret = new EMFReferenceModel(resource);
		} else {
			ret = new EMFModel((EMFReferenceModel)referenceModel, resource);
		}
		return ret;
	}

	public EMFModel loadModel(ReferenceModel referenceModel, Injector injector, Map<String, ProjectorActualParameter<?>> params) {
		EMFModel model = this.createModel(referenceModel);
		try {
			injector.inject(model, params);
		} catch (InjectorException e) {
			e.printStackTrace();
		}
		return model;
	}

	public void saveModel(Model model, Extractor extractor, Map<String, ProjectorActualParameter<?>> params) {
		if (!this.isHandling(model)) {
			throw new IllegalArgumentException("model is not handled by EMFModelHandler");
		}
		try {
			extractor.extract(model, params);
		} catch (ExtractorException e) {
			e.printStackTrace();
		}
	}
}
