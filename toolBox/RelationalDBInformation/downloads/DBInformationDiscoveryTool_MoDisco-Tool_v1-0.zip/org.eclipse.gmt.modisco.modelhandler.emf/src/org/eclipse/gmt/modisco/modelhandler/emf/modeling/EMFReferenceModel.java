/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.modelhandler.emf.modeling;

import java.util.Iterator;

import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.modelhandler.emf.EMFModelHandler;

public class EMFReferenceModel extends EMFModel implements ReferenceModel {

	private static EMFReferenceModel metametamodel;
	
	public EMFReferenceModel(Resource resource) {
		super(EMFReferenceModel.getMetametamodel(), resource);
		computeAllPackages(this);
	}
	
	// Should be used only for metametamodel creation
	private EMFReferenceModel(EMFReferenceModel referenceModel, Resource resource) {
		super(referenceModel, resource);
		computeAllPackages(this);
	}
	
	public static EMFReferenceModel getMetametamodel() {
		if(metametamodel == null) {
			metametamodel = new EMFReferenceModel(null, EcorePackage.eINSTANCE.eResource());
			metametamodel.setReferenceModel(metametamodel);
		}
		computeAllPackages(metametamodel);
		return metametamodel;
	}
	
	public EMFReferenceModelElement getReferenceModelElementByName(String fullyQualifiedName) {
		String[] splitted = this.splitFullyQualifiedName(fullyQualifiedName);
		EMFReferenceModelElement founded = null;
		for (Object current : this.getResource().getContents()) {
			if (current instanceof ENamedElement) {
				EMFReferenceModelElement me = (EMFReferenceModelElement)this.getEMFModelElementFromEObject((EObject)current);
				String name = (String)me.get("name");
				if ( (((EObject)current).eContents() != null) 
						&& splitted[1] != null
						&& splitted[0].equals(name) ) {
					founded = getReferenceModelElementByName(splitted[1], (EObject)current);
				} else {
					if (name.equals(splitted[0])) {
						return me;
					}
				}
			} else {
				continue;
			}
		}
		return founded;
	}
	
	protected EMFReferenceModelElement getReferenceModelElementByName(String fullyQualifiedName, EObject eObject) {
		String[] splitted = this.splitFullyQualifiedName(fullyQualifiedName);
		EMFReferenceModelElement founded = null;
		for (Object current : eObject.eContents()) { 
			if (current instanceof ENamedElement) {
				EMFReferenceModelElement me = (EMFReferenceModelElement)this.getEMFModelElementFromEObject((EObject)current);
				String name = (String)me.get("name");
				if ( (((EObject)current).eContents() != null) 
						&& splitted[1] != null
						&& splitted[0].equals(name) ) {
					founded = getReferenceModelElementByName(splitted[1], (EObject)current);
				} else {
					if (name.equals(splitted[0])) {
						return me;
					}
				}
			} else {
				continue;
			}
		}
		return founded;
	}
		
	private static String[] splitFullyQualifiedName(String fullyQualifiedName) {
		String[] splitted = new String[2];
		if (fullyQualifiedName.indexOf(EMFModelHandler.CONTAINER_SEPARATOR) != -1) {  
			splitted[0] = fullyQualifiedName.substring(0, fullyQualifiedName.indexOf(EMFModelHandler.CONTAINER_SEPARATOR));
			splitted[1] = fullyQualifiedName.substring(fullyQualifiedName.indexOf(EMFModelHandler.CONTAINER_SEPARATOR) + EMFModelHandler.CONTAINER_SEPARATOR.length());
		} else {
			splitted[0] = fullyQualifiedName;
			splitted[1] = null;
		}
		return splitted;
	}
	
	// TODO: put in protected visibility
	public void setResource(Resource resource) {
		super.setResource(resource);
		computeAllPackages(this);
	}
	
	/**
	 * @param referenceModel
	 */
	private static void computeAllPackages(EMFReferenceModel referenceModel) {
		for (Object e: referenceModel.getResource().getContents()) {
			if (e instanceof EPackage) {
				referenceModel.getResource().getResourceSet().getPackageRegistry().put(((EPackage)e).getNsURI(), (EPackage)e);
				computeAllPackages(referenceModel, (EPackage)e);
			}
		}
	}
	
	/**
	 * @param referenceModel
	 * @param ePackage
	 */
	private static void computeAllPackages(EMFReferenceModel referenceModel, EPackage ePackage) {		
		Iterator subPackages = ePackage.getESubpackages().iterator();
		while (subPackages.hasNext()) {
			EPackage e = (EPackage)subPackages.next();
			referenceModel.getResource().getResourceSet().getPackageRegistry().put(e.getNsURI(), e);
			computeAllPackages(referenceModel, e);
		}
	}
	
}
