/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.javast;

import java.util.HashMap;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.Annotation;
import org.eclipse.jdt.core.dom.AnnotationTypeDeclaration;
import org.eclipse.jdt.core.dom.AnnotationTypeMemberDeclaration;
import org.eclipse.jdt.core.dom.AnonymousClassDeclaration;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.ArrayCreation;
import org.eclipse.jdt.core.dom.ArrayInitializer;
import org.eclipse.jdt.core.dom.ArrayType;
import org.eclipse.jdt.core.dom.AssertStatement;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BlockComment;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.CatchClause;
import org.eclipse.jdt.core.dom.CharacterLiteral;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Comment;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ConditionalExpression;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.EmptyStatement;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.EnumConstantDeclaration;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IExtendedModifier;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.ImportDeclaration;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.Initializer;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.Javadoc;
import org.eclipse.jdt.core.dom.LabeledStatement;
import org.eclipse.jdt.core.dom.LineComment;
import org.eclipse.jdt.core.dom.MarkerAnnotation;
import org.eclipse.jdt.core.dom.MemberRef;
import org.eclipse.jdt.core.dom.MemberValuePair;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.MethodRef;
import org.eclipse.jdt.core.dom.MethodRefParameter;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.Name;
import org.eclipse.jdt.core.dom.NormalAnnotation;
import org.eclipse.jdt.core.dom.NullLiteral;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.eclipse.jdt.core.dom.PackageDeclaration;
import org.eclipse.jdt.core.dom.ParameterizedType;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.PostfixExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.QualifiedType;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleMemberAnnotation;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;
import org.eclipse.jdt.core.dom.SuperFieldAccess;
import org.eclipse.jdt.core.dom.SuperMethodInvocation;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.SynchronizedStatement;
import org.eclipse.jdt.core.dom.TagElement;
import org.eclipse.jdt.core.dom.TextElement;
import org.eclipse.jdt.core.dom.ThisExpression;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TryStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclarationStatement;
import org.eclipse.jdt.core.dom.TypeLiteral;
import org.eclipse.jdt.core.dom.TypeParameter;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationExpression;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jdt.core.dom.WildcardType;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.Model;

public class ASTDiscoverer extends ASTVisitor {

	private HashMap<ASTNode, ModelElement> map;
	private Model astModel;
	private ModelElement astRoot;

	public ASTDiscoverer(Model astModel, ModelElement astRoot) {
		super(true);
		this.map = new HashMap<ASTNode, ModelElement>();
		this.astModel = astModel;
		this.astRoot = astRoot;
		
//		try {
//			this.astRoot = astModel. astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::AST"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		astModel.addRootElement(astRoot);
	}

	@Override
	public void endVisit(AnnotationTypeDeclaration node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAbstractTypeDeclaration(node, modiscoNode);
	}

	@Override
	public void endVisit(AnnotationTypeMemberDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("default", this.map.get(node.getDefault()));
		this.map.remove(node.getDefault());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(AnonymousClassDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		for (BodyDeclaration element : (List<BodyDeclaration>)node.bodyDeclarations()) {
			modiscoNode.add("bodyDeclarations", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ArrayAccess node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("array", this.map.get(node.getArray()));
		this.map.remove(node.getArray());
		
		modiscoNode.set("index", this.map.get(node.getIndex()));
		this.map.remove(node.getIndex());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ArrayCreation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("initializer", this.map.get(node.getInitializer()));
		this.map.remove(node.getInitializer());
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (Expression element : (List<Expression>)node.dimensions()) {
			modiscoNode.add("dimensions", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ArrayInitializer node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		for (Expression element : (List<Expression>)node.expressions()) {
			modiscoNode.add("expressions", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ArrayType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("dimensions", node.getDimensions());
		
		modiscoNode.set("componentType", this.map.get(node.getComponentType()));
		this.map.remove(node.getComponentType());
		
		modiscoNode.set("elementType", this.map.get(node.getElementType()));
		this.map.remove(node.getElementType());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(AssertStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("message", this.map.get(node.getMessage()));
		this.map.remove(node.getMessage());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(Assignment node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("operator", node.getOperator().toString());
				
		modiscoNode.set("leftHandSide", this.map.get(node.getLeftHandSide()));
		this.map.remove(node.getLeftHandSide());
		
		modiscoNode.set("rightHandSide", this.map.get(node.getRightHandSide()));
		this.map.remove(node.getRightHandSide());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(Block node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		for (Statement element : (List<Statement>)node.statements()) {
			modiscoNode.add("statements", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(BlockComment node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitComment(node, modiscoNode);
	}

	@Override
	public void endVisit(BooleanLiteral node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("booleanValue", node.booleanValue());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(BreakStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("label", this.map.get(node.getLabel()));
		this.map.remove(node.getLabel());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(CastExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(CatchClause node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
				
		modiscoNode.set("exception", this.map.get(node.getException()));
		this.map.remove(node.getException());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(CharacterLiteral node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("charValue", node.charValue());
		modiscoNode.set("escapedValue", node.getEscapedValue());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ClassInstanceCreation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("anonymousClassDeclaration", this.map.get(node.getAnonymousClassDeclaration()));
		this.map.remove(node.getAnonymousClassDeclaration());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (Expression element : (List<Expression>)node.arguments()) {
			modiscoNode.add("arguments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Type element : (List<Type>)node.typeArguments()) {
			modiscoNode.add("typeArguments", this.map.get(element));
			this.map.remove(element);
		} 
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	
	/*   CompilationUnit:
      		[ PackageDeclaration ]
        	{ ImportDeclaration }
        	{ TypeDeclaration | EnumDeclaration | AnnotationTypeDeclaration | ; }
	 */
	public void endVisit(CompilationUnit node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("package", this.map.get(node.getPackage()));
		this.map.remove(node.getPackage());
		
		for (ImportDeclaration element : (List<ImportDeclaration>)node.imports()) {
			modiscoNode.add("imports", this.map.get(element));
			this.map.remove(element);
		}		
		
		for (AbstractTypeDeclaration element : (List<AbstractTypeDeclaration>)node.types()) {
			modiscoNode.add("types", this.map.get(element));
			this.map.remove(element);
		}		
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ConditionalExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);

		modiscoNode.set("elseExpression", this.map.get(node.getElseExpression()));
		this.map.remove(node.getElseExpression());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("thenExpression", this.map.get(node.getThenExpression()));
		this.map.remove(node.getThenExpression());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ConstructorInvocation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		for (Expression element : (List<Expression>)node.arguments()) {
			modiscoNode.add("arguments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Type element : (List<Type>)node.typeArguments()) {
			modiscoNode.add("typeArguments", this.map.get(element));
			this.map.remove(element);
		} 
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ContinueStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("label", this.map.get(node.getLabel()));
		this.map.remove(node.getLabel());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(DoStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(EmptyStatement node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
	}

	@Override
	public void endVisit(EnhancedForStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("parameter", this.map.get(node.getParameter()));
		this.map.remove(node.getParameter());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(EnumConstantDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("anonymousClassDeclaration", this.map.get(node.getAnonymousClassDeclaration()));
		this.map.remove(node.getAnonymousClassDeclaration());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(EnumDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAbstractTypeDeclaration(node, modiscoNode);
		
		for (EnumConstantDeclaration element : (List<EnumConstantDeclaration>)node.enumConstants()) {
			modiscoNode.add("enumConstants", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Type element : (List<Type>)node.superInterfaceTypes()) {
			modiscoNode.add("superInterfaceTypes", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ExpressionStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(FieldAccess node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(FieldDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (VariableDeclarationFragment element : (List<VariableDeclarationFragment>)node.fragments()) {
			modiscoNode.add("fragments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ForStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		for (VariableDeclarationExpression element : (List<VariableDeclarationExpression>)node.initializers()) {
			modiscoNode.add("initializers", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Expression element : (List<Expression>)node.updaters()) {
			modiscoNode.add("updaters", this.map.get(element));
			this.map.remove(element);
		}  
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(IfStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("elseStatement", this.map.get(node.getElseStatement()));
		this.map.remove(node.getElseStatement());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("thenStatement", this.map.get(node.getThenStatement()));
		this.map.remove(node.getThenStatement());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ImportDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("onDemand", node.isOnDemand());
		modiscoNode.set("static", node.isStatic());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(InfixExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);

		modiscoNode.set("operator", node.getOperator().toString());
		
		modiscoNode.set("leftOperand", this.map.get(node.getLeftOperand()));
		this.map.remove(node.getLeftOperand());
		
		modiscoNode.set("rightOperand", this.map.get(node.getRightOperand()));
		this.map.remove(node.getRightOperand());

		for (Expression element : (List<Expression>)node.extendedOperands()) {
			modiscoNode.add("extendedOperands", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(Initializer node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(InstanceofExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("leftOperand", this.map.get(node.getLeftOperand()));
		this.map.remove(node.getLeftOperand());
		
		modiscoNode.set("rightOperand", this.map.get(node.getRightOperand()));
		this.map.remove(node.getRightOperand());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(Javadoc node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitComment(node, modiscoNode);
		
		for (TagElement element : (List<TagElement>)node.tags()) {
			modiscoNode.add("tags", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(LabeledStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
		
		modiscoNode.set("label", this.map.get(node.getLabel()));
		this.map.remove(node.getLabel());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(LineComment node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitComment(node, modiscoNode);
	}

	@Override
	public void endVisit(MarkerAnnotation node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAnnotation(node, modiscoNode);
	}

	@Override
	public void endVisit(MemberRef node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(MemberValuePair node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("value", this.map.get(node.getValue()));
		this.map.remove(node.getValue());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(MethodDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("extraDimensions", node.getExtraDimensions());
		modiscoNode.set("constructor", node.isConstructor());
		modiscoNode.set("varargs", node.isVarargs());
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("returnType", this.map.get(node.getReturnType2()));
		this.map.remove(node.getReturnType2());
		
		for (Name element : (List<Name>)node.thrownExceptions()) {
			modiscoNode.add("thrownExceptions", this.map.get(element));
			this.map.remove(element);
		}
		
		for (TypeParameter element : (List<TypeParameter>)node.typeParameters()) {
			modiscoNode.add("typeParameters", this.map.get(element));
			this.map.remove(element);
		}
		
		for (SingleVariableDeclaration element : (List<SingleVariableDeclaration>)node.parameters()) {
			modiscoNode.add("parameters", this.map.get(element));
			this.map.remove(element);
		} 
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(MethodInvocation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		 
		for (Expression element : (List<Expression>)node.arguments()) {
			modiscoNode.add("arguments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(MethodRef node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
		
		for (MethodRefParameter element : (List<MethodRefParameter>)node.parameters()) {
			modiscoNode.add("parameters", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(MethodRefParameter node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("varargs", node.isVarargs());
			
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(Modifier node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("abstract", node.isAbstract());
		modiscoNode.set("final", node.isFinal());
		modiscoNode.set("native", node.isNative());
		modiscoNode.set("private", node.isPrivate());
		modiscoNode.set("protected", node.isProtected());
		modiscoNode.set("public", node.isPublic());
		modiscoNode.set("static", node.isStatic());
		modiscoNode.set("strictfp", node.isStrictfp());
		modiscoNode.set("synchronized", node.isSynchronized());
		modiscoNode.set("transient", node.isTransient());
		modiscoNode.set("volatile", node.isVolatile());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(NormalAnnotation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAnnotation(node, modiscoNode);
		
		for (MemberValuePair element : (List<MemberValuePair>)node.values()) {
			modiscoNode.add("values", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(NullLiteral node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
	}

	@Override
	public void endVisit(NumberLiteral node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("token", node.getToken());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(PackageDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("javadoc", this.map.get(node.getJavadoc()));
		this.map.remove(node.getJavadoc());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		for (Annotation element : (List<Annotation>)node.annotations()) {
			modiscoNode.add("annotations", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ParameterizedType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (Type element : (List<Type>)node.typeArguments()) {
			modiscoNode.add("typeArguments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(ParenthesizedExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(PostfixExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("operator", node.getOperator().toString());
		
		modiscoNode.set("operand", this.map.get(node.getOperand()));
		this.map.remove(node.getOperand());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(PrefixExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("operator", node.getOperator().toString());
		
		modiscoNode.set("operand", this.map.get(node.getOperand()));
		this.map.remove(node.getOperand());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(PrimitiveType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("code", node.getPrimitiveTypeCode().toString());
	} catch(Exception e) { e.printStackTrace();} }

	@Override
	public void endVisit(QualifiedName node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitName(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(QualifiedType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(ReturnStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SimpleName node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitName(node, modiscoNode);
		
		modiscoNode.set("declaration", node.isDeclaration());
		modiscoNode.set("identifier", node.getIdentifier());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SimpleType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SingleMemberAnnotation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAnnotation(node, modiscoNode);
		
		modiscoNode.set("value", this.map.get(node.getValue()));
		this.map.remove(node.getValue());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SingleVariableDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitVariableDeclaration(node, modiscoNode);
		
		modiscoNode.set("varargs", node.isVarargs());
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (IExtendedModifier element : (List<IExtendedModifier>)node.modifiers()) {
			modiscoNode.add("modifiers", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(StringLiteral node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("escapedValue", node.getEscapedValue());
		modiscoNode.set("literalValue", node.getLiteralValue());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SuperConstructorInvocation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		for (Expression element : (List<Expression>)node.arguments()) {
			modiscoNode.add("arguments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Type element : (List<Type>)node.typeArguments()) {
			modiscoNode.add("typeArguments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SuperFieldAccess node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SuperMethodInvocation node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
		
		for (Expression element : (List<Expression>)node.arguments()) {
			modiscoNode.add("arguments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (Type element : (List<Type>)node.typeArguments()) {
			modiscoNode.add("typeArguments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SwitchCase node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("default", node.isDefault());
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SwitchStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		for (Statement element : (List<Statement>)node.statements()) {
			modiscoNode.add("statements", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(SynchronizedStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TagElement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("tagName", node.getTagName());
		modiscoNode.set("nested", node.isNested());
		
		for (ASTNode element : (List<ASTNode>)node.fragments()) {
			modiscoNode.add("fragments", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TextElement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("text", node.getText());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(ThisExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("qualifier", this.map.get(node.getQualifier()));
		this.map.remove(node.getQualifier());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(ThrowStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TryStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());

		modiscoNode.set("finally", this.map.get(node.getFinally()));
		this.map.remove(node.getFinally());
		
		for (CatchClause element : (List<CatchClause>)node.catchClauses()) {
			modiscoNode.add("catchClauses", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TypeDeclaration node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitAbstractTypeDeclaration(node, modiscoNode);
		
		modiscoNode.set("interface", node.isInterface());
		
		modiscoNode.set("superclassType", this.map.get(node.getSuperclassType()));
		this.map.remove(node.getSuperclassType());
		
		for (Type element : (List<Type>)node.superInterfaceTypes()) {
			modiscoNode.add("superInterfaceTypes", this.map.get(element));
			this.map.remove(element);
		}
		
		for (TypeParameter element : (List<TypeParameter>)node.typeParameters()) {
			modiscoNode.add("typeParameters", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TypeDeclarationStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("declaration", this.map.get(node.getDeclaration()));
		this.map.remove(node.getDeclaration());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TypeLiteral node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(TypeParameter node) {try {
		ModelElement modiscoNode = this.map.get(node);
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		for (Type element : (List<Type>)node.typeBounds()) {
			modiscoNode.add("typeBounds", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(VariableDeclarationExpression node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitExpression(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (VariableDeclarationFragment element : (List<VariableDeclarationFragment>)node.fragments()) {
			modiscoNode.add("fragments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (IExtendedModifier element : (List<IExtendedModifier>)node.modifiers()) {
			modiscoNode.add("modifiers", this.map.get(element));
			this.map.remove(element);
		}
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(VariableDeclarationFragment node) {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitVariableDeclaration(node, modiscoNode);
	}

	@Override
	public void endVisit(VariableDeclarationStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("type", this.map.get(node.getType()));
		this.map.remove(node.getType());
		
		for (VariableDeclarationFragment element : (List<VariableDeclarationFragment>)node.fragments()) {
			modiscoNode.add("fragments", this.map.get(element));
			this.map.remove(element);
		}
		
		for (IExtendedModifier element : (List<IExtendedModifier>)node.modifiers()) {
			modiscoNode.add("modifiers", this.map.get(element));
			this.map.remove(element);
		}  
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(WhileStatement node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitStatement(node, modiscoNode);
		
		modiscoNode.set("expression", this.map.get(node.getExpression()));
		this.map.remove(node.getExpression());
		
		modiscoNode.set("body", this.map.get(node.getBody()));
		this.map.remove(node.getBody());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void endVisit(WildcardType node) {try {
		ModelElement modiscoNode = this.map.get(node);
		this.endVisitType(node, modiscoNode);
		
		modiscoNode.set("upperBound", node.isUpperBound());
		
		modiscoNode.set("bound", this.map.get(node.getBound()));
		this.map.remove(node.getBound());
	} catch(Exception e) { e.printStackTrace();System.exit(0);} }

	@Override
	public void postVisit(ASTNode node) {
		if (node instanceof CompilationUnit) {
			this.map.remove(node);
			if (this.map.size() != 0) {
				try {
					throw new Exception("Map souhld be empty, everything is not well parsed !!");
				} catch (Exception e) {
					for (ASTNode n: this.map.keySet()) {
						System.out.println(n.getClass() + " -> " + n.getParent().getClass());
					}
					e.printStackTrace();System.exit(0);
				}
			}
		}
	}

	@Override
	public void preVisit(ASTNode node) {
	}

	@Override
	public boolean visit(AnnotationTypeDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::AnnotationTypeDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(AnnotationTypeMemberDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("org.eclipse.modisco.java.JavaAST::AnnotationTypeMemberDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(AnonymousClassDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::AnonymousClassDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ArrayAccess node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ArrayAccess"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ArrayCreation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ArrayCreation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ArrayInitializer node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ArrayInitializer"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ArrayType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ArrayType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(AssertStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::AssertStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(Assignment node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::Assignment"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(Block node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::Block"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(BlockComment node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::BlockComment"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(BooleanLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::BooleanLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(BreakStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::BreakStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(CastExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::CastExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(CatchClause node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::CatchClause"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(CharacterLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::CharacterLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ClassInstanceCreation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ClassInstanceCreation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(CompilationUnit node) {
		/*List comments = (node).getCommentList();
		
		for (Iterator i = comments.iterator(); i.hasNext();) {
			Comment current = (Comment) i.next();
			if (current.getParent() == null) {
				current.accept(this);
			}
		}*/
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::CompilationUnit"));
			this.astRoot.set("compilationUnits", modiscoNode);
			//this.astModel.addRootElement(modiscoNode);
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}	
		return true;
	}

	@Override
	public boolean visit(ConditionalExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ConditionalExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ConstructorInvocation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ConstructorInvocation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ContinueStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ContinueStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(DoStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::DoStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(EmptyStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::EmptyStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(EnhancedForStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::EnhancedForStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(EnumConstantDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::EnumConstantDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(EnumDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::EnumDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ExpressionStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ExpressionStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(FieldAccess node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::FieldAccess"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(FieldDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::FieldDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ForStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ForStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(IfStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::IfStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ImportDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ImportDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(InfixExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::InfixExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(Initializer node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::Initializer"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(InstanceofExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::InstanceofExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(Javadoc node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::Javadoc"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(LabeledStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::LabeledStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(LineComment node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::LineComment"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MarkerAnnotation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MarkerAnnotation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MemberRef node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MemberRef"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MemberValuePair node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MemberValuePair"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MethodDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MethodDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MethodInvocation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MethodInvocation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MethodRef node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MethodRef"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(MethodRefParameter node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::MethodRefParameter"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(Modifier node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::Modifier"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(NormalAnnotation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::NormalAnnotation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(NullLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::NullLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(NumberLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::NumberLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(PackageDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::PackageDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ParameterizedType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ParameterizedType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ParenthesizedExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ParenthesizedExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(PostfixExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::PostfixExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(PrefixExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::PrefixExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(PrimitiveType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::PrimitiveType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(QualifiedName node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::QualifiedName"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(QualifiedType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::QualifiedType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ReturnStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ReturnStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SimpleName node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SimpleName"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SimpleType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SimpleType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SingleMemberAnnotation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SingleMemberAnnotation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SingleVariableDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SingleVariableDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(StringLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::StringLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SuperConstructorInvocation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SuperConstructorInvocation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SuperFieldAccess node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SuperFieldAccess"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SuperMethodInvocation node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SuperMethodInvocation"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SwitchCase node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SwitchCase"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SwitchStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SwitchStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(SynchronizedStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::SynchronizedStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TagElement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TagElement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TextElement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TextElement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ThisExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ThisExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(ThrowStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::ThrowStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TryStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TryStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TypeDeclaration node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TypeDeclaration"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TypeDeclarationStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TypeDeclarationStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TypeLiteral node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TypeLiteral"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(TypeParameter node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::TypeParameter"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(VariableDeclarationExpression node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::VariableDeclarationExpression"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(VariableDeclarationFragment node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::VariableDeclarationFragment"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(VariableDeclarationStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::VariableDeclarationStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(WhileStatement node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::WhileStatement"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}

	@Override
	public boolean visit(WildcardType node) {
		try {
			ModelElement modiscoNode = this.astModel.createModelElement(this.astModel.getReferenceModel().getReferenceModelElementByName("JavaAST::WildcardType"));
			this.map.put(node, modiscoNode);
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
		return true;
	}
	
	private void endVisitAbstractTypeDeclaration(AbstractTypeDeclaration node, ModelElement modiscoNode) {
		try {
		this.endVisitBodyDeclaration(node, modiscoNode);
		
		modiscoNode.set("localTypeDeclaration", node.isLocalTypeDeclaration());
		modiscoNode.set("memberTypeDeclaration", node.isMemberTypeDeclaration());
		modiscoNode.set("packageMemberTypeDeclaration", node.isPackageMemberTypeDeclaration());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		
		for (BodyDeclaration element : (List<BodyDeclaration>)node.bodyDeclarations()) {
			modiscoNode.add("bodyDeclarations", this.map.get(element));
			this.map.remove(element);
		}
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
	}
	
	private void endVisitAnnotation(Annotation node, ModelElement modiscoNode) {
	try{
		modiscoNode.set("typeName", this.map.get(node.getTypeName()));
		this.map.remove(node.getTypeName());
	} catch (Exception e) {
		e.printStackTrace();System.exit(0);
	}
	}
	
	private void endVisitBodyDeclaration(BodyDeclaration node, ModelElement modiscoNode) {
		try {
		modiscoNode.set("javadoc", this.map.get(node.getJavadoc()));
		this.map.remove(node.getJavadoc());
		
		for (IExtendedModifier element : (List<IExtendedModifier>)node.modifiers()) {
			modiscoNode.add("modifiers", this.map.get(element));
			this.map.remove(element);
		}
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
	}

	private void endVisitComment(Comment node, ModelElement modiscoNode) {
	}
	
	private void endVisitExpression(Expression node, ModelElement modiscoNode) {
		try {
		modiscoNode.set("resolveBoxing", node.resolveBoxing());
		modiscoNode.set("resolveUnboxing", node.resolveUnboxing());
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
	}

	private void endVisitName(Name node, ModelElement modiscoNode) {
		try{
		this.endVisitExpression(node, modiscoNode);
		modiscoNode.set("fullyQualifiedName", node.getFullyQualifiedName());
	
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
	}
	
	private void endVisitStatement(Statement node, ModelElement modiscoNode) {	
	}
	
	private void endVisitType(Type node, ModelElement modiscoNode) {
	}
	
	private void endVisitVariableDeclaration(VariableDeclaration node, ModelElement modiscoNode) {
		try {
		modiscoNode.set("extraDimensions", node.getExtraDimensions());
		
		modiscoNode.set("initializer", this.map.get(node.getInitializer()));
		this.map.remove(node.getInitializer());
		
		modiscoNode.set("name", this.map.get(node.getName()));
		this.map.remove(node.getName());
		} catch (Exception e) {
			e.printStackTrace();System.exit(0);
		}
	}
}
