/*
 * Copyright (c) 2006, 2007 ATLAS. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     Mika�l Barbero
 * 
 */

package org.eclipse.gmt.modisco.javast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.modelhandler.emf.EMFModelHandler;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFReferenceModel;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFExtractor;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFInjector;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;

public class Main {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		String javaFile = "src/org/eclipse/gmt/modisco/javast/ASTDiscoverer.java";
		
		ModelHandler emh = new EMFModelHandler();
		
		Injector emfinj = EMFInjector.getInstance();
		Map<String, ProjectorActualParameter<?>> params = new HashMap<String, ProjectorActualParameter<?>>();
		
		params.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI("src/org/eclipse/gmt/modisco/javast/resources/JavaAST.ecore")));
		ReferenceModel astMM = (ReferenceModel)emh.loadModel(EMFReferenceModel.getMetametamodel(), emfinj, params);
		
		Model astm = emh.createModel(astMM);
		
		ModelElement astRoot = astm.createModelElement(astMM.getReferenceModelElementByName("JavaAST::AST"));
		
		//String modelName = javaFile.substring(javaFile.indexOf('/')+1).replaceAll(".java", "").replace('/', '.');
		System.out.println("Extracting " + javaFile + "...");
		
		try {
			File file = new File(javaFile);
			BufferedReader in = new BufferedReader(new FileReader(file));
			StringBuffer buffer = new StringBuffer();
			String line = null;
			while (null != (line = in.readLine())) {
				buffer.append("\t" + line);
				buffer.append("\n");
			}

			ASTParser parser = ASTParser.newParser(AST.JLS3);
			parser.setKind(ASTParser.K_COMPILATION_UNIT);
			final String text = buffer.toString();
			parser.setSource(text.toCharArray());
			CompilationUnit node = (CompilationUnit) parser.createAST(null);

			ASTVisitor visitor = new ASTDiscoverer(astm, astRoot);
			node.accept(visitor);

			params.clear();
			params.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI("samples/" + javaFile.replace(".java", ".ecore").replace('/', '.'))));
			emh.saveModel(astm, EMFExtractor.getInstance(), params);

		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Done !");
	}

}
