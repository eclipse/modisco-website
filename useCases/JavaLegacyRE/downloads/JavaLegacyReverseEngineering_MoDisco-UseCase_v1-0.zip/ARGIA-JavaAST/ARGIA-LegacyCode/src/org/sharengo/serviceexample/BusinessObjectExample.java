package org.sharengo.serviceexample;

public class BusinessObjectExample extends BusinessObjectBase{

	public void boMethod(Object[] args) throws BusinessException{
		
		//my business rules			
		if( args[4] == "toto")
			throw new BusinessException("ERROR-517585");
		
	}

}
