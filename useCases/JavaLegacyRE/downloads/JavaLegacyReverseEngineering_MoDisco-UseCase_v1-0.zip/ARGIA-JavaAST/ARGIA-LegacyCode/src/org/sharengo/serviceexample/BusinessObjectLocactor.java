package org.sharengo.serviceexample;

public class BusinessObjectLocactor {

	public static BusinessObjectExample getBusinessObject(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
