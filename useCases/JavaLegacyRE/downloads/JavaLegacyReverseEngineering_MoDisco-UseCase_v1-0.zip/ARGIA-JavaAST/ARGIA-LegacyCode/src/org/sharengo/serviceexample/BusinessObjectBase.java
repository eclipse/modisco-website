package org.sharengo.serviceexample;

public class BusinessObjectBase {

}
