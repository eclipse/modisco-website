package org.sharengo.serviceexample;

public class BusinessException extends Exception {

	public BusinessException(String string) {
		// TODO Auto-generated constructor stub
	}

}
