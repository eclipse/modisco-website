package org.sharengo.serviceexample;

public class ServiceExample extends ServiceBase{

	public void serviceMethod(Object...args) throws BusinessException{
		
		if( args[0] == null)
			throw new BusinessException("CODE3");
		try {			
			BusinessObjectExample businessObject = (BusinessObjectExample) BusinessObjectLocactor.getBusinessObject("BusinessObjectExample");
			businessObject.boMethod(args);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	
	}

	public void serviceMethod2(Object...args){
		
		try {			
			if( args[0] == null)
				throw new BusinessException("CODE1");
			
			if( args[1] == null)
				throw new BusinessException("CODE2");
			
			BusinessObjectExample businessObject = (BusinessObjectExample) BusinessObjectLocactor.getBusinessObject("BusinessObjectExample");
			businessObject.boMethod(args);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
