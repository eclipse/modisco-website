package org.sharengo.serviceexample;

public class ServiceBase {

}
