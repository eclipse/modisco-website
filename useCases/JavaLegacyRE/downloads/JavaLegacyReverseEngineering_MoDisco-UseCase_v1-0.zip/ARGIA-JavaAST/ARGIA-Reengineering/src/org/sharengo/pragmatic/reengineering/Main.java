package org.sharengo.pragmatic.reengineering;

import org.atl.engine.vm.nativelib.ASMModel;

/**
 * Botstrap Modisco and ATL to provide sample of reverse engineering mechanism.
 * 
 * @author benois@argia-engineering - belmonte@argia-engineering 
 * @since 2007/02/22
 */
public class Main {

	public static void main(String[] args) {
		final String repository = "LegacyRepository";
		String ast=null;
		ASMModel targetModel;
		try {			
			GenerateAST generateAST = new GenerateAST(repository);				
			TransformAST transformer = new TransformAST();
			//Create empty target model
			targetModel = transformer.newModel();
			
			// Apply reverse mechanism on ServiceExample class
			ast = generateAST.generate("../ARGIA-LegacyCode/src/org/sharengo/serviceexample/ServiceExample.java");			
			transformer.process(repository+"/"+ast, targetModel);
			
			//Apply reverse mechanism on BusinessObjectExample class
			ast=generateAST.generate("../ARGIA-LegacyCode/src/org/sharengo/serviceexample/BusinessObjectExample.java");
			transformer.process(repository+"/"+ast, targetModel);
			
			//Save target model in XMI
			transformer.saveModel(targetModel);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
