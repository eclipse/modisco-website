package org.sharengo.pragmatic.reengineering;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.gmt.modisco.core.modelhandler.ModelHandler;
import org.eclipse.gmt.modisco.core.modeling.Model;
import org.eclipse.gmt.modisco.core.modeling.ModelElement;
import org.eclipse.gmt.modisco.core.modeling.ReferenceModel;
import org.eclipse.gmt.modisco.core.projectors.Injector;
import org.eclipse.gmt.modisco.core.projectors.ProjectorActualParameter;
import org.eclipse.gmt.modisco.javast.ASTDiscoverer;
import org.eclipse.gmt.modisco.modelhandler.emf.EMFModelHandler;
import org.eclipse.gmt.modisco.modelhandler.emf.modeling.EMFReferenceModel;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFExtractor;
import org.eclipse.gmt.modisco.modelhandler.emf.projectors.EMFInjector;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;

/**
 * Analyze java source code and generate EMF model conform to Java AST metamodel 
 * 
 * @author benois@argia-engineering - belmonte@argia-engineering 
 * @since 2007/02/22
 */
public class GenerateAST {

	private ModelHandler emh;
	private ReferenceModel astmm;
	
	// Default constructor
	public GenerateAST(String emfRepository) throws Exception {
			emh = new EMFModelHandler();
			
			Injector emfinj = EMFInjector.getInstance();
			Map<String, ProjectorActualParameter<?>> params = new HashMap<String, ProjectorActualParameter<?>>();
			params.put("URI", new ProjectorActualParameter<URI>(URI.createFileURI("MetaModels/JavaAST.ecore")));
			astmm = (ReferenceModel)emh.loadModel(EMFReferenceModel.getMetametamodel(), emfinj, params);
	        if( astmm == null) {
	        	throw new Exception("JavaAST Ecore metamodel not found");
	        }
	}
	
	/**
	 * Generate AST for given file
	 * 
	 * @param javaFile java source code file
	 * @return JavaAST EMF model instance
	 * @throws Exception
	 */
	public String generate(String javaFile) throws Exception {
         System.out.print("Extracting " + javaFile + "...");
         System.out.flush();
         
         Model astm = emh.createModel(astmm);

         try {
			File file = new File(javaFile);
			BufferedReader in = new BufferedReader(new FileReader(file));
			StringBuffer buffer = new StringBuffer();
			String line = null;
			while (null != (line = in.readLine())) {
				buffer.append("\t" + line);
				buffer.append("\n");
			}

			ASTParser parser = ASTParser.newParser(AST.JLS3);
			parser.setKind(ASTParser.K_COMPILATION_UNIT);
			final String text = buffer.toString();
			parser.setSource(text.toCharArray());
			CompilationUnit node = (CompilationUnit) parser.createAST(null);
			
			ModelElement astRoot = astm.createModelElement(astmm.getReferenceModelElementByName("JavaAST::AST"));
			ASTVisitor visitor = new ASTDiscoverer(astm, astRoot);
			node.accept(visitor);

			Map<String, ProjectorActualParameter<?>> params = new HashMap<String, ProjectorActualParameter<?>>();
			params.put("URI", new ProjectorActualParameter<URI>(URI
					.createFileURI("LegacyRepository/"
							+ javaFile.replace("../", "").replace("./", "").replace(".java", ".ecore").replace('/',
									'.'))));
			emh.saveModel(astm, EMFExtractor.getInstance(), params);
			
			System.out.println(" done");

		} catch (Exception e) {
			System.out.println(" failed");
			System.out.println(e);
		}
		return javaFile.replace("../", "").replace("./", "").replace(".java", ".ecore").replace('/', '.');
	}

}
