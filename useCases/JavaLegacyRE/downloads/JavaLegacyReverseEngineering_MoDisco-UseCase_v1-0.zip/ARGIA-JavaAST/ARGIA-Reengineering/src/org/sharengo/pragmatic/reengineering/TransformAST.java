package org.sharengo.pragmatic.reengineering;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.atl.eclipse.engine.AtlLauncher;
import org.atl.eclipse.engine.AtlModelHandler;
import org.atl.engine.vm.nativelib.ASMModel;

/**
 * Apply ATL transformation to extract semantic information in order to populate logical model 
 * conform to sharengo metamodel 
 * 
 * @author benois@argia-engineering - belmonte@argia-engineering 
 * @since 2007/02/22
 */
public class TransformAST {
	final static String resultXmiPath = "result.xmi";
	AtlModelHandler amh=null;
	ASMModel javaMetamodel=null;
	ASMModel sharengoMetamodel=null;
	Map<String, URL> libs=null;
	//Define params
	Map params = Collections.EMPTY_MAP;
	
	// Default constructor
	public TransformAST() {
		try {
			//Load EMF sub system
			amh = AtlModelHandler.getDefault(AtlModelHandler.AMH_EMF);
			
			// Load JavaAST Metamodel			
			InputStream inJavaMetamodel = new FileInputStream("MetaModels/JavaAST.ecore");		
			this.javaMetamodel = amh.loadModel("JavaAST", amh.getMof(),inJavaMetamodel);
			inJavaMetamodel.close();
	
			// Load Sharengo Metamodel			
			InputStream inSharengoMetamodel = new FileInputStream("MetaModels/Sharengo.ecore");
			this.sharengoMetamodel = amh.loadModel("IN", amh.getMof(), inSharengoMetamodel); 
			inSharengoMetamodel.close();
			
			// Load librarys
			this.libs = new HashMap<String, URL>();			
			URL javaASTLibAsmUrl = new File("Transformations/JavaASTLib.asm").toURI().toURL();
			this.libs.put("JavaASTLib", javaASTLibAsmUrl);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Apply ATL transformation in order to populate given logical model
	 * 
	 * @param ecoreFile JavaAST model
	 * @param targetModel Logical model to populate
	 * @return
	 */
	public ASMModel process(String ecoreFile, ASMModel targetModel){			
		try {			
			// Load first JavaAST model
			System.out.println("====> " + ecoreFile);
			InputStream inFirstJavaModel = new FileInputStream(ecoreFile);
			ASMModel firstJavaModel = amh.loadModel("JavaClass", javaMetamodel,inFirstJavaModel);
			firstJavaModel.setIsTarget(false);
			inFirstJavaModel.close();
		
			// Load ASM models
			Map<String, ASMModel> models = new HashMap<String, ASMModel>();
			models.put("JavaAST", javaMetamodel);
			models.put("Sharengo", sharengoMetamodel);
			models.put("IN", firstJavaModel);
			models.put("OUT", targetModel);

			// Launch transformation
			AtlLauncher atlLauncher = AtlLauncher.getDefault();
			URL asmUrl = new File("Transformations/JavaAST2SharengoMM.asm").toURI().toURL();			
			atlLauncher.launch(asmUrl, libs, models, params);
			
			System.out.println("Model transformation done.");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return targetModel;
	}
	
	public void saveModel(ASMModel targetModel){
		//Write result model
		amh.saveModel(targetModel, resultXmiPath);	
	}
	
	public ASMModel newModel() throws IOException{	
		ASMModel targetModel = amh.newModel("resultModel", sharengoMetamodel);		
		targetModel.setIsTarget(true);
		return targetModel;
	}
	
}
