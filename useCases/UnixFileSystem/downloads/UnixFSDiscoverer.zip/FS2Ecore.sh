#!/bin/bash

error() {
	echo $1
}

tabulate() {
	local i=0
	while [ $i -lt $1 ]; do
		echo -ne "    ";
		let "i+=1"
	done
}

create_directory_open_tag() {
	echo -ne "<contents xsi:type=\"UnixFS:Directory\" name=\"$1\" owner=\"$2\" group=\"$3\""
		if [ $4 -gt 0 ]; then
			echo ">"
		else
			echo "/>"
		fi
}

create_file_open_tag() {
	echo -ne "<contents xsi:type=\"UnixFS:TextFile\" name=\"$1\" owner=\"$2\" group=\"$3\""
		if [ $4 -gt 0 ]; then
			echo ">"
		else
			echo "/>"
		fi
}

create_file_close_tag() {
	echo "</contents>"
}

create_directory_close_tag() {
	echo "</contents>"
}

if [ -z "`echo "${1}" | grep "^\/"`" ]; then
	error "You sould specify an absolute path..."
	exit 1
fi

if [ -d ${1} ]; then
	echo -ne;
else
	error "The specified directory doesn't exist..."
	exit 2
fi

ROOT_DIR=`echo $1 | sed 's/\/*$//g'`
find $ROOT_DIR -type d -name "*" > /tmp/dirlist

ROOT_DEPTH=`echo -n $ROOT_DIR | awk 'BEGIN { FS = "/" } { print NF }'`

PREVIOUS=""
PREVIOUS_BASENAME=""
PREVIOUS_DIRNAME=""

PREVIOUS_DIR_DEPTH=-1
CURRENT_DIR_DEPTH=0

PREVIOUS_CURRENT_NB_FILES_IN_DIR=0
PREVIOUS_CURRENT_NB_DIRS_IN_DIR=0

echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"
echo "<UnixFS:FileSystemRoot xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:UnixFS=\"UnixFS\">"

for CURRENT in `cat /tmp/dirlist`; do
	CURRENT_BASENAME=`basename $CURRENT`
	CURRENT_DIRNAME=`dirname $CURRENT`

	ls -Al $CURRENT | grep "^\-" | awk 'BEGIN { FS = " " } { print $NF }' > /tmp/files_in_dir
	ls -Al $CURRENT | grep "^\d" | awk 'BEGIN { FS = " " } { print $NF }' > /tmp/dirs_in_dir
	
	OWNER=`ls -ld $CURRENT"/" | awk 'BEGIN { FS = " " } { print $3 }'`
	GROUP=`ls -ld $CURRENT"/" | awk 'BEGIN { FS = " " } { print $4 }'`

	CURRENT_NB_FILES_IN_DIR=`cat /tmp/files_in_dir | wc -l`
	CURRENT_NB_DIRS_IN_DIR=`cat /tmp/dirs_in_dir | wc -l`
	
	let "CURRENT_DIR_DEPTH = `echo -n $CURRENT | awk 'BEGIN { FS = "/" } { print NF }'` - $ROOT_DEPTH"	

	if [ $PREVIOUS_DIR_DEPTH -lt $CURRENT_DIR_DEPTH ]; then
		#DEEPER	
		tabulate $CURRENT_DIR_DEPTH
		create_directory_open_tag $CURRENT_BASENAME $OWNER $GROUP `expr $CURRENT_NB_FILES_IN_DIR + $CURRENT_NB_DIRS_IN_DIR` 

	elif [ $PREVIOUS_DIR_DEPTH -eq $CURRENT_DIR_DEPTH ]; then
		#SAME DEPTH

		if [ `expr $PREVIOUS_NB_FILES_IN_DIR + $PREVIOUS_NB_DIRS_IN_DIR` -gt 0 ]; then
			tabulate $CURRENT_DIR_DEPTH
			create_directory_close_tag
		fi

		tabulate $CURRENT_DIR_DEPTH
		create_directory_open_tag $CURRENT_BASENAME $OWNER $GROUP `expr $CURRENT_NB_FILES_IN_DIR + $CURRENT_NB_DIRS_IN_DIR`

	else
		#PARENT
		DEPTH_DIFF=`expr $PREVIOUS_DIR_DEPTH - $CURRENT_DIR_DEPTH`

		if [ $DEPTH_DIFF -ge 1 ]; then
			j=$DEPTH_DIFF
			while [ $j -gt 0 ]; do
				tabulate `expr $CURRENT_DIR_DEPTH + $j`
				create_directory_close_tag
				let "j-=1"
			done
		fi
		if [ `expr $PREVIOUS_NB_FILES_IN_DIR + $PREVIOUS_NB_DIRS_IN_DIR` -gt 0 ]; then
			tabulate $CURRENT_DIR_DEPTH
			create_directory_close_tag
		fi

		tabulate $CURRENT_DIR_DEPTH
		create_directory_open_tag $CURRENT_BASENAME $OWNER $GROUP `expr $CURRENT_NB_FILES_IN_DIR + $CURRENT_NB_DIRS_IN_DIR`
	fi

	for CURRENT_FILE in `cat /tmp/files_in_dir`; do
		OWNER=`ls -l $CURRENT"/"$CURRENT_FILE | awk 'BEGIN { FS = " " } { print $3 }'`
		GROUP=`ls -l $CURRENT"/"$CURRENT_FILE | awk 'BEGIN { FS = " " } { print $4 }'`
		tabulate `expr 1 + $CURRENT_DIR_DEPTH`
		create_file_open_tag "$CURRENT_FILE" $OWNER $GROUP 0
	done;

	PREVIOUS=$CURRENT
	PREVIOUS_BASENAME=$CURRENT_BASENAME
	PREVIOUS_DIRNAME=$CURRENT_DIRNAME
	PREVIOUS_NB_FILES_IN_DIR=$CURRENT_NB_FILES_IN_DIR
	PREVIOUS_NB_DIRS_IN_DIR=$CURRENT_NB_DIRS_IN_DIR
	PREVIOUS_DIR_DEPTH=$CURRENT_DIR_DEPTH
done;

DEPTH_DIFF=`expr $PREVIOUS_DIR_DEPTH - $CURRENT_DIR_DEPTH`

if [ $DEPTH_DIFF -ge 1 ]; then
	j=$DEPTH_DIFF
	while [ $j -gt 0 ]; do
		tabulate `expr $CURRENT_DIR_DEPTH + $j`
		create_directory_close_tag
		let "j-=1"
	done
fi
if [ `expr $PREVIOUS_NB_FILES_IN_DIR + $PREVIOUS_NB_DIRS_IN_DIR` -gt 0 ]; then
	tabulate $CURRENT_DIR_DEPTH
	create_directory_close_tag
fi

while [ $CURRENT_DIR_DEPTH -gt 0 ]; do
	let "CURRENT_DIR_DEPTH -= 1"
	tabulate $CURRENT_DIR_DEPTH
	create_directory_close_tag
done

echo "</UnixFS:FileSystemRoot>"

## Removing temporary files
rm -f /tmp/dirlist /tmp/files_in_dir /tmp/dirs_in_dir